const baseUrl = "https://dhiti-website-backend.vercel.app";

export const fetchProjects = async (category) => {
  return fetch(`${baseUrl}/project/getall`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      // Include other headers as needed, such as authorization headers
    },
    body: JSON.stringify({ category }), // Dynamically using the `category` parameter
  }).then((res) => res.json());
};

export const fetchTopProject = () => {
  return fetch(`${baseUrl}/project/gettopprojects`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
    },
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Failed to fetch top projects");
      }
      return response.json();
    })
    .catch((error) => {
      throw new Error(error.message || "Failed to fetch top projects");
    });
};


export const fetchTopBlogs = () => {
  return fetch(`${baseUrl}/blog/getall`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
    },
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Failed to fetch top projects");
      }
      return response.json();
    })
    .catch((error) => {
      throw new Error(error.message || "Failed to fetch top projects");
    });
};