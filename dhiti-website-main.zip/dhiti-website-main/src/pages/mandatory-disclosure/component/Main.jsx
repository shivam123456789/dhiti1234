import React from 'react';

const Main = () => {

    const disclosuredata = [
        {
            heading: "ORGANISATIONAL POLICIES",
            data: [
                {
                    url: "",
                    name: "Annual Report ",
                }, {
                    url: "",
                    name: "Annual Report ",
                }, {
                    url: "",
                    name: "Annual Report ",
                },
            ]
        }, {
            heading: "ANNUAL AUDITED FINANCIAL STATEMENTS",
            data: [
                {
                    url: "",
                    name: "Annual Report ",
                }, {
                    url: "",
                    name: "Annual Report ",
                }, {
                    url: "",
                    name: "Annual Report ",
                },
            ]

        }, {
            heading: "ANNUAL ACTIVITY REPORTS",
            data: [
                {
                    url: "",
                    name: "Annual Report ",
                }, {
                    url: "",
                    name: "Annual Report ",
                }, {
                    url: "",
                    name: "Annual Report ",
                },
            ]
        }, {
            heading: "ORGANISATIONAL POLICIES",
            data: [
                {
                    url: "",
                    name: "Annual Report ",
                }, {
                    url: "",
                    name: "Annual Report ",
                }, {
                    url: "",
                    name: "Annual Report ",
                },
            ]
        }, {
            heading: "ORGANISATIONAL POLICIES",
            data: [
                {
                    url: "",
                    name: "Annual Report ",
                }, {
                    url: "",
                    name: "Annual Report ",
                }, {
                    url: "",
                    name: "Annual Report ",
                },
            ]
        },

    ]

    const annualdata = [{
        year: "YEAR 2023-2024",
        data: [
            {
                yearname: "year report 2022"

            }, {
                yearname: "year report 2022"
            }, {
                yearname: "year report 2022"
            }
        ]
    }, {
        year: "YEAR 2023-2024",
        data: [
            {
                yearname: "year report 2022"

            }, {
                yearname: "year report 2022"
            }, {
                yearname: "year report 2022"
            }
        ]
    }, {
        year: "YEAR 2023-2024",
        data: [
            {
                yearname: "year report 2022"

            }, {
                yearname: "year report 2022"
            }, {
                yearname: "year report 2022"
            }
        ]
    }, {
        year: "YEAR 2023-2024",
        data: [
            {
                yearname: "year report 2022"

            }, {
                yearname: "year report 2022"
            }, {
                yearname: "year report 2022"
            }
        ]
    }

    ]

    const oldsummary = [
        {
            url: "",
            name: "summary of FC Receipt"
        },
        {
            url: "",
            name: "summary of FC Receipt"
        },
        {
            url: "",
            name: "summary of FC Receipt"
        },
        {
            url: "",
            name: "summary of FC Receipt"
        }
    ]

    return (
        <>
            <div class="xl:max-w-screen-xl font-quicksand pt-6 md:pt-12 pb-6 lg:pb-10 mx-auto px-6 sm:px-6 md:px-8 lg:px-12 ">
                 <h4 class=" lg:text-3xl xl:text-5xl font-bold mb-6 text-gray-900 md:text-5xl text-4xl">
                 MANDATORY DISCLOSURE
            </h4>
            {/*
            <div class="prose text-xl prose-lg lg:prose-xl xl:prose-2xl ">
                Gram Vikas’ work is driven by its core values of inclusion, equity and dignity. Each of us in Gram Vikas are committed to practicing and nurturing an organisational culture that reflects and affirms these values: work embedded in the community; people as our most important asset; openness to new ideas and different views, being transparent about our decisions and collaborative; resilience and agility to respond to the changes around us.
            </div> */}
                {/* <div class="flex flex-col sm:relative sm:before:absolute sm:before:top-2 sm:before:w-4 sm:before:h-4 sm:before:rounded-full sm:before:left-[-35px] sm:before:z-[1]">
              
                <img className='mt-5 mb-5' src="https://www.gramvikas.org/wp-content/themes/gramvikas/img/history/History_2nd_Decade_1992_Ashram_School.jpg" alt="" />
            </div> */}

                {/* <div class="flex gap-4 flex-wrap my-4 md:mt-8">
                                        <a href="#"
                                            class="bg-indigo-600 hover:bg-indigo-700 transition ease-in-out duration-150 text-base text-white px-4 lg:px-8 py-4 inline-block font-bold rounded-md shadow-xl">Start
                                            Browse
                                        </a>

                                        <a href=""
                                            class="bg-white hover:bg-yellow-200 text-base text-indigo-600 px-4 lg:px-8 py-4 inline-block font-bold rounded-md shadow-xl transition ease-in-out duration-150">
                                            Our impact
                                        </a>
                                    </div> */}

                {disclosuredata.map((result, key) => (
                    <div>
                        <h4 class=" lg:text-3xl xl:text-3xl font-bold mb-6 text-gray-900 md:text-5xl text-4xl">
                            {result.heading}
                        </h4>

                        <div className='grid grid-cols-3 gap-3'>

                            {result.data.map((data) => (
                                <div class="prose text-xl prose-lg lg:prose-xl xl:prose-2xl py-5 text-gray-900 cursor-pointer">
                                    {data.name}
                                </div>
                            ))}
                        </div>
                    </div>

                ))}
            </div>

            <div class="xl:max-w-screen-xl font-quicksand  pb-6 lg:pb-10 mx-auto px-6 sm:px-6 md:px-8 lg:px-12 ">
                <h4 class=" lg:text-3xl xl:text-5xl font-bold mb-6 text-gray-900 md:text-5xl text-4xl">
                    STATEMENT OF FUND RECEIPT & UTILISATION FROM FOREIGN SOURCES
                </h4>

                {annualdata.map((result, key) => (
                    <div className='cursor-pointer'>
                        <h4 class=" lg:text-3xl xl:text-3xl font-bold mb-6 text-gray-900 md:text-5xl text-4xl">
                            {result.year}
                        </h4>
                        <div className='grid grid-cols-3 gap-3'>

                            {result.data.map((data) => (
                                <div class="prose text-xl prose-lg lg:prose-xl xl:prose-2xl py-5 text-gray-900 ">
                                    {data.yearname}
                                </div>
                            ))}
                        </div>

                    </div>

                ))}
            </div>
            <div class="xl:max-w-screen-xl font-quicksand  pb-6 lg:pb-10 mx-auto px-6 sm:px-6 md:px-8 lg:px-12 ">
                <h4 class=" lg:text-3xl xl:text-3xl font-bold mb-6 text-gray-900 md:text-5xl text-4xl">
                    OLD SUMMARY RECEIPTS
                </h4>
                <div className='grid grid-cols-3 gap-3'>



                    {oldsummary.map((data) => (
                        <div class="prose text-xl prose-lg lg:prose-xl xl:prose-2xl py-5 text-gray-900  cursor-pointer">
                            {data.name}
                        </div>
                    ))}
                </div>

            </div>
        </>
    );
};

export default Main;