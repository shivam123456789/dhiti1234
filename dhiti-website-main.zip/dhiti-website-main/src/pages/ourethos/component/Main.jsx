import React from 'react';

const Main = () => {

    const ethosdata = [
        {
            heading: "We are embedded in the community",
            des: [
                {
                    description: "All of what we do, idea and practice, starts from the communities we partner with. It is how we started out in 1971 and it’s how we will move forward. We are a community development organisation. Projects do not determine the work we do in the villages. Instead, everything that we do is derived from an expressed need of the communities.",

                }, {
                    description: "Every single outcome of Gram Vikas’ work, whether its practice or policy, is co-created with the communities – their knowledge, capacities and efforts. High levels of community engagement, deep respect for their knowledge, and implicit trust in their capacities drive our efforts. We seek to strengthen the collective agency of the communities so that they can chart their paths to dignified lives. This means, we are guided by solidarity rather than by charity.",
                }, {
                    description: "From ideation and design to implementation and ownership of outcomes, our work is marked by the involvement of communities as equal partners.",
                }
            ]
        }, {
            heading: "We have people at the centre",
            des: [
                {
                    description: "The people in our organisation are our most important asset. We trust and believe in their abilities. We strive to build a workplace that nurtures excellence and professionalism. The opportunities offered are interesting, meaningful and challenging. Individuals give their best to what they do, when they are able to bring their authentic and complete selves to their workplaces. We share and celebrate our joys, achievements, fears and sorrows together.",

                }, {
                    description: "Our path breaking work in the communities stands on our value of inclusion. We embrace the same values in building our teams. We offer equal opportunities without discrimination on the basis of caste, religion, gender identity, ability, age and sexual orientation.",
                }
            ]
        }, {
            heading: "We are open, transparent and collaborative",
            des: [
                {
                    description: "We remain committed to each other’s growth as to our own. We act on this by being open to new ideas and contrarian views. We give feedback with empathy and accept it with humility. We are unafraid to have authentic and difficult conversations. We are respectful and unambiguous when we talk to each other. There is clear communication of Gram Vikas’ vision and policies.",

                }, {
                    description: "We are transparent about the decisions taken and the reasons for those choices. We are collaborative within and across teams, with our communities and all other stakeholders. This means, we acknowledge and respect other’s ideas, roles, competencies, ways of working, and contributions.",
                }
            ]
        }, {
            heading: "We are agile and resilient",
            des: [
                {
                    description: "We recognise that we live in a world that is volatile, uncertain, complex and ambiguous. Our ability to make effective change depends on being able to navigate and flourish in this environment. Hence, we are committed to embracing change and taking risks without compromising on our core values.",

                }, {
                    description: "Technology, new knowledge and experimentation aid us to be agile in this journey. We value new knowledge just as we embrace indigenous knowledge systems. A culture of experimentation and learning from failures help us to continuously grow and evolve. We are mindful of the ethics of technology use even as we adopt it to do better.",
                }, {
                    description: "Thriving in an uncertain world demands resilience from individuals, teams and systems. At work, we invest in building communities of support for each other, where all voices are valued. This is our source of resilience.",
                }
            ]
        }
    ]


    return (
        <div>
            <div class="xl:max-w-screen-xl font-quicksand pt-6 md:pt-12 pb-6 lg:pb-10 mx-auto px-6 sm:px-6 md:px-8 lg:px-12 xl:pt-24">
                <h4 class=" lg:text-3xl xl:text-5xl font-bold mb-6 text-gray-900 md:text-5xl text-4xl">
                    OUR ETHOS & CULTURE
                </h4>
                <div class="prose text-xl prose-lg lg:prose-xl xl:prose-2xl ">
                    Gram Vikas’ work is driven by its core values of inclusion, equity and dignity. Each of us in Gram Vikas are committed to practicing and nurturing an organisational culture that reflects and affirms these values: work embedded in the community; people as our most important asset; openness to new ideas and different views, being transparent about our decisions and collaborative; resilience and agility to respond to the changes around us.
                </div>
                <div class="flex flex-col sm:relative sm:before:absolute sm:before:top-2 sm:before:w-4 sm:before:h-4 sm:before:rounded-full sm:before:left-[-35px] sm:before:z-[1]">
                    {/* <h3 class="text-xl font-semibold tracking-wide">{das.year}</h3>
                                            <time class="text-xs tracking-wide uppercase dark:text-gray-400">Dec 2020</time>
                                            <p class="mt-3">{das.descrip}</p> */}
                    <img className='mt-5 mb-5' src="https://www.gramvikas.org/wp-content/themes/gramvikas/img/history/History_2nd_Decade_1992_Ashram_School.jpg" alt="" />
                </div>

                {/* <div class="flex gap-4 flex-wrap my-4 md:mt-8">
                                        <a href="#"
                                            class="bg-indigo-600 hover:bg-indigo-700 transition ease-in-out duration-150 text-base text-white px-4 lg:px-8 py-4 inline-block font-bold rounded-md shadow-xl">Start
                                            Browse
                                        </a>

                                        <a href=""
                                            class="bg-white hover:bg-yellow-200 text-base text-indigo-600 px-4 lg:px-8 py-4 inline-block font-bold rounded-md shadow-xl transition ease-in-out duration-150">
                                            Our impact
                                        </a>
                                    </div> */}

                {ethosdata.map((result, key) => (
                    <div>
                        <h4 class=" lg:text-3xl xl:text-5xl font-bold mb-6 text-gray-900 md:text-5xl text-4xl">
                            {result.heading}
                        </h4>

                        {result.des.map((data) => (
                            <div class="prose text-xl prose-lg lg:prose-xl xl:prose-2xl py-5 text-gray-900">
                                {data.description}
                            </div>
                        ))}

                    </div>

                ))}

                <div className="flex justify-center">
                    <a href='/brandandteam'>
                        <button

                            type="submit"
                            className="p-3 border-2 border-green text-black text-xl hover:bg-green font-semibold hover:text-white mt-4 w-auto font-quicksand rounded-md text-center align-center justify-center items-center whitespace-nowrap"
                        >
                            {"VIEW OUR TEAM"}
                        </button>

                    </a>

                </div>
                {/* <div class="xl:max-w-screen-xl font-quicksand pt-6 md:pt-12 pb-6 lg:pb-10 mx-auto px-6 sm:px-6 md:px-8 lg:px-12 xl:pt-24"> */}
                <h4 class=" lg:text-3xl xl:text-5xl font-bold mb-3 text-gray-900 md:text-5xl text-4xl mt-10">
                    HEAR FROM OUR PEOPLE
                </h4>
                <div className='container  p-5  flex mx-auto h-[350px] flex-col mb-10 '>
                    <video className="w-[600px]  h-full mx-auto rounded" controls>
                        <source src="https://docs.material-tailwind.com/demo.mp4" type="video/mp4" />
                        EMBEDDED IN THE COMMUNITY
                    </video>
                    <h4 class="  font-bold mb-0 text-gray-900 text-xl  mt-2 mx-auto">
                        EMBEDDED IN THE COMMUNITY
                    </h4>
                    <p className='mx-auto '>Gram Vikas community partners and team share about their experiences.</p>

                </div>
                {/* </div> */}


            </div>

        </div>
    );
};

export default Main;