import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import Navbar from './NavBar';
// import { NavbarWithMegaMenu } from './NavBar2';
// import TopBar from './TopBar';


const Navigation = () => {
    const location = useLocation();

    useEffect(() => {
        window.scrollTo(0, 0);
    }, [location]);

    return (
        <>
            {/* <TopBar /> */}
            <Navbar />
            {/* <NavbarWithMegaMenu/> */}
        </>
    );
};

export default Navigation;