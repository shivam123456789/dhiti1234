import React, { useEffect } from "react";
import { BiSolidDollarCircle } from "react-icons/bi";
import Logo from "../../assets/logo.png";
import {
  Navbar,
  MobileNav,
  Typography,
  Button,
  IconButton,
  Collapse,
} from "@material-tailwind/react";
import { NavLink } from "react-router-dom";
import { Link } from "react-router-dom";
import { IoIosArrowDown } from "react-icons/io";

const Navigation = () => {
  const [openNav, setOpenNav] = React.useState(false);
  const [eventDropdownOpen, setEventDropdownOpen] = React.useState(false);
  const [aboutDropdownOpen, setAboutDropdownOpen] = React.useState(false);
  const [whyUsDropdownOpen, setWhyUsDropdownOpen] = React.useState(false);
  const [documentDropdownOpen, setDocumentDropdownOpen] = React.useState(false);

  const showDonateButton = window.innerWidth >= 960;

  useEffect(() => {
    window.addEventListener(
      "resize",
      () => window.innerWidth >= 960 && setOpenNav(false)
    );
  }, []);

  const handleEventMouseEnter = () => {
    if (!openNav) {
      setEventDropdownOpen(true);
    }
  };

  const handleEventMouseLeave = () => {
    if (!openNav) {
      setEventDropdownOpen(false);
    }
  };
  const handleAboutMouseEnter = () => {
    if (!openNav) {
      setAboutDropdownOpen(true);
    }
  };

  const handleAboutMouseLeave = () => {
    if (!openNav) {
      setAboutDropdownOpen(false);
    }
  };

  const handleWhyUsMouseEnter = () => {
    if (!openNav) {
      setWhyUsDropdownOpen(true);
    }
  };

  const handleWhyUsMouseLeave = () => {
    if (!openNav) {
      setWhyUsDropdownOpen(false);
    }
  };

  const handleDocumentMouseEnter = () => {
    if (!openNav) {
      setDocumentDropdownOpen(true);
    }
  };

  const handleDocumentMouseLeave = () => {
    if (!openNav) {
      setDocumentDropdownOpen(false);
    }
  };

  const navList = (
    <ul className="flex flex-col gap-2 lg:mb-0 lg:mt-0 lg:flex-row lg:items-center lg:gap-6">
      <Typography
        as="li"
        variant="small"
        color="blue-gray"
        className="p-1 font-normal"
      >
        <NavLink
          to="/"
          className="flex items-center font-medium md:text-lg text-md text-gray-500 hover:text-green lg:hover:border-b-2 hover:border-green font-quicksand"
        >
          Home
        </NavLink>
      </Typography>
      {/* <li
        className="relative"
        onMouseEnter={handleWhyUsMouseEnter}
        onMouseLeave={handleWhyUsMouseLeave}
      >
        <Typography
          as="div"
          variant="small"
          color="blue-gray"
          className={`p-1 font-normal font-quicksand ${
            whyUsDropdownOpen ? "text-gray-500" : "text-gray-500"
          }`}
        >
          <div
            className="flex items-center md:text-lg hover:text-green justify-between font-medium text-md cursor-pointer"
            onClick={() => setWhyUsDropdownOpen(!whyUsDropdownOpen)}
          >
            Why Us
            <span className="ml-3 text-green-600 cursor-pointer">
              {whyUsDropdownOpen ? (
                <IoIosArrowDown className="hover:text-green" />
              ) : (
                <IoIosArrowDown className="hover:text-green" />
              )}
            </span>
          </div>
          {whyUsDropdownOpen && (
            <ul
              className={`absolute top-full left-0 z-10 bg-white justify-center items-center text-gray-600 md:border-green p-4 w-[10rem] md:border-b-4 rounded-md`}
            >
              <li>
                <NavLink
                  to="/whyus/vision-and-approach"
                  className={`block p-2 hover:bg-white rounded-md border-purple font-medium text-md mt-4 hover:text-green`}
                >
                  Vision & Approach
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/whyus/impact"
                  className={`block p-2 hover:bg-white md:text-md rounded-md border-purple font-medium text-md mt-4 hover:text-green`}
                >
                  Impact
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/whyus/recognition"
                  className={`block p-2 hover:bg-white md:text-md rounded-md border-purple font-medium text-md mt-4 hover:text-green`}
                >
                  Recognition
                </NavLink>
              </li>
            </ul>
          )}
        </Typography>
      </li> */}

      <li
        className="relative"
        onMouseEnter={handleAboutMouseEnter}
        onMouseLeave={handleAboutMouseLeave}
      >
        <Typography
          as="div"
          variant="small"
          color="blue-gray"
          className={`p-1 font-normal font-quicksand ${
            aboutDropdownOpen ? "text-gray-500" : "text-gray-500"
          }`}
        >
          <div
            className="flex items-center md:text-lg hover:text-green justify-between font-medium text-md cursor-pointer"
            onClick={() => setAboutDropdownOpen(!aboutDropdownOpen)}
          >
            About Us
            <span className="ml-3 text-green-600 cursor-pointer">
              {aboutDropdownOpen ? (
                <IoIosArrowDown className="hover:text-green" />
              ) : (
                <IoIosArrowDown className="hover:text-green" />
              )}
            </span>
          </div>
          {aboutDropdownOpen && (
            <ul
              className={`absolute top-8 left-0 z-20 bg-white justify-center items-center text-gray-600 md:border-green p-4 w-[10rem] md:border-b-4  rounded-md`}
            >
              <li>
                <NavLink
                  to="/history"
                  className={`block p-2 hover:bg-white rounded-md md:text-md border-green font-medium text-md mt-4 hover:text-green`}
                >
                  Our Story
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/whyus/vision-and-approach"
                  className={`block p-2 hover:bg-white md:text-md rounded-md border-green font-medium text-md mt-4 hover:text-green`}
                >
                  Vision & Mission
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/ethos&culture"
                  className={`block p-2 hover:bg-white md:text-md rounded-md border-green font-medium text-md mt-4 hover:text-green`}
                >
                  Media
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/mandatory-disclosure"
                  className={`block p-2 hover:bg-white md:text-md rounded-md border-green font-medium text-md mt-4 hover:text-green`}
                >
                  Our Team
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/library"
                  className={`block p-2 hover:bg-white md:text-md rounded-md border-green font-medium text-md mt-4 hover:text-green`}
                >
                  Testimonial
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/brandandteam"
                  className={`block p-2 hover:bg-white md:text-md rounded-md border-green font-medium text-md mt-4 hover:text-green`}
                >
                  Accreditation
                </NavLink>
              </li>
            </ul>
          )}
        </Typography>
      </li>

      <li
        className="relative"
        onMouseEnter={handleEventMouseEnter}
        onMouseLeave={handleEventMouseLeave}
      >
        <Typography
          as="div"
          variant="small"
          color="blue-gray"
          className={`p-1 font-normal font-quicksand ${
            eventDropdownOpen ? "text-gray-500" : "text-gray-500"
          }`}
        >
          <div
            className="flex items-center md:text-lg hover:text-green justify-between font-medium text-md cursor-pointer"
            onClick={() => setEventDropdownOpen(!eventDropdownOpen)}
          >
            Our Work
            <span className="ml-3 text-green-600 cursor-pointer">
              {eventDropdownOpen ? (
                <IoIosArrowDown className="hover:text-green" />
              ) : (
                <IoIosArrowDown className="hover:text-green" />
              )}
            </span>
          </div>
          {eventDropdownOpen && (
            <ul
              className={`absolute top-8 left-0 z-10 bg-white justify-center items-center text-gray-600 md:border-green p-4 w-[10rem] md:border-b-4  rounded-md`}
            >
              <li>
                <NavLink
                  to="/ourwork/education"
                  className={`block p-2 hover:bg-white rounded-md border-purple font-medium text-md mt-4 hover:text-green`}
                >
                  Education
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/ourwork/youth-welfare"
                  className={`block p-2 hover:bg-white rounded-md border-purple font-medium text-md mt-4 hover:text-green`}
                >
                  Youth and Welfare
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/ourwork/environment-one-health"
                  className={`block p-2 hover:bg-white rounded-md border-purple font-medium text-md mt-4 hover:text-green`}
                >
                  Enviroment and One Health
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/ourwork/health-campaign"
                  className={`block p-2 hover:bg-white rounded-md border-purple font-medium text-md mt-4 hover:text-green`}
                >
                  Health and Campaign
                </NavLink>
              </li>
              {/* <li>
                <NavLink
                  to="/ourwork/residence"
                  className={`block p-2 hover:bg-white rounded-md border-purple font-medium text-md mt-4 hover:text-green`}
                >
                  Residence Facilities
                </NavLink>
              </li>
              <li>
                <NavLink
                  to="/ourwork/livelihood"
                  className={`block p-2 hover:bg-white rounded-md border-purple font-medium text-md mt-4 hover:text-green`}
                >
                  Livelihood
                </NavLink>
              </li> */}
            </ul>
          )}
        </Typography>
      </li>
      {/* <Typography
        as="li"
        variant="small"
        color="blue-gray"
        className="p-1 font-normal"
      >
        <li
          className="relative"
          onMouseEnter={handleDocumentMouseEnter}
          onMouseLeave={handleDocumentMouseLeave}
        >
          <Typography
            as="div"
            variant="small"
            color="blue-gray"
            className={`p-1 font-normal font-quicksand ${
              documentDropdownOpen ? "text-gray-500" : "text-gray-500"
            }`}
          >
            <div
              className="flex items-center md:text-lg hover:text-green justify-between font-medium text-md cursor-pointer"
              onClick={() => setDocumentDropdownOpen(!documentDropdownOpen)}
            >
              Document
              <span className="ml-3 text-green-600 cursor-pointer">
                {documentDropdownOpen ? (
                  <IoIosArrowDown className="hover:text-green" />
                ) : (
                  <IoIosArrowDown className="hover:text-green" />
                )}
              </span>
            </div>
            {documentDropdownOpen && (
              <ul
                className={`absolute top-8 left-0 z-20 bg-white justify-center items-center text-gray-600 md:border-green p-4 w-[10rem] md:border-b-4  rounded-md`}
              >
                <li>
                  <NavLink
                    to="/gallery"
                    className={`block p-2 hover:bg-white md:text-md rounded-md border-green font-medium text-md mt-4 hover:text-green`}
                  >
                    Annual Report
                  </NavLink>
                </li>
                <li>
                  <NavLink
                    to="/gallery"
                    className={`block p-2 hover:bg-white md:text-md rounded-md border-green font-medium text-md mt-4 hover:text-green`}
                  >
                    Internships
                  </NavLink>
                </li>
              </ul>
            )}
          </Typography>
        </li>
      </Typography> */}

      <Typography
        as="li"
        variant="small"
        color="blue-gray"
        className="p-1 font-normal font-quicksand"
      >
        <NavLink
          to="/blog"
          className="flex  items-center font-medium md:text-lg text-md text-gray-500 lg:hover:text-green  lg:hover:border-b-2 lg:hover:border-green font-quicksand"
        >
          Blog
        </NavLink>
      </Typography>
    </ul>
  );

  return (
    <div>
      <Navbar className=" mx-auto max-w-screen py-1 px-4 lg:px-8 lg:py-1 shadow-sm rounded-xs shadow-gray-200 overflow-visible">
        <div className="container mx-auto flex items-center justify-between text-blue-gray-900">
          <NavLink to="/" className="-ml-2">
            <img
              src={Logo}
              alt="Dhiti Foundation"
              className="mb-4 main-logo md:ml-6 ml-2"
            />
          </NavLink>
          <div className="hidden lg:block font-quicksand md:-mr-[26%] -mr-[31%]">
            {navList}
          </div>
          {showDonateButton && (
            <Link to={"https://dhiti-seven.vercel.app/aryomtech/S46iev8qgxXpkhl8al3USm0dlB92/-NiYJsP0vZ7n_85ghOH0"}>
              <Button
                variant="gradient"
                size="sm"
                className="mb-2 mt-2 mr-12 flex items-center text-gray-600 bg-[#d90414] text-white rounded-sm hover:bg-primary "
              >
                <BiSolidDollarCircle className="mr-2" />
                <span className="mr-1 font-quicksand text-sm font-medium capitalize">
                  Donate
                </span>
              </Button>
            </Link>
          )}
          <IconButton
            variant="text"
            className="ml-auto mr-2 h-6 w-6 text-blue-600 hover-bg-transparent focus-bg-transparent active-bg-transparent lg:hidden"
            ripple={false}
            onClick={() => setOpenNav(!openNav)}
          >
            {openNav ? (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                className="h-6 w-6 text-green"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={2}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            ) : (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6 text-green "
                fill="none"
                stroke="currentColor"
                strokeWidth={2}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M4 6h16M4 12h16M4 18h16"
                />
              </svg>
            )}
          </IconButton>
        </div>

        <MobileNav open={openNav}>
          <div className="container mx-auto pb-4">
            {navList}
            {/* <Link to="/donate"> */}
            <Link to={"https://dhiti-seven.vercel.app/aryomtech/S46iev8qgxXpkhl8al3USm0dlB92/-NiYJsP0vZ7n_85ghOH0"}>
              <Button
                variant="gradient"
                size="sm"
                className="flex items-center rounded-sm capitalize  bg-green hover:bg-primary"
              >
                <BiSolidDollarCircle className="mr-2" />
                <span className="mr-1">Donate</span>
              </Button>
            </Link>
          </div>
        </MobileNav>
      </Navbar>
    </div>
  );
};
export default Navigation;
