import {
  GiFruitBowl,
  GiWaterBottle,
  GiHealthCapsule,
  GiTeacher,
} from "react-icons/gi";
import { MdMapsHomeWork } from "react-icons/md";
import { FaPeopleCarry } from "react-icons/fa";
import { Link } from "react-router-dom";

const services = [
  {
    icon: <GiFruitBowl className="h-14 w-14 text-green" />,
    title: "Healthy Food",
    description:
      "Providing nutritious and delicious meals for your well-being.",
    url: "/ourwork/food",
  },
  {
    icon: <GiWaterBottle className="h-14 w-14 text-green" />,
    title: "Pure Water",
    description: "Ensuring access to clean and safe drinking water for all.",
    url: "/ourwork/water",
  },
  {
    icon: <GiHealthCapsule className="h-14 w-14 text-green" />,
    title: "Health Care",
    description:
      "Delivering quality healthcare services to promote a healthy community.",
    url: "/ourwork/health",
  },
  {
    icon: <GiTeacher className="h-14 w-14 text-green" />,
    title: "Primary Education",
    description:
      "Empowering young minds through quality primary education programs.",
    url: "/ourwork/education",
  },
  {
    icon: <MdMapsHomeWork className="h-14 w-14 text-green" />,
    title: "Residence Facilities",
    description:
      "Providing safe and comfortable housing for individuals and families.",
    url: "/ourwork/residence",
  },
  {
    icon: <FaPeopleCarry className="h-14 w-14 text-green" />,
    title: "Social Care",
    description:
      "Supporting and caring for our community with compassion and dedication.",
    url: "/ourwork/livelihood",
  },
];

const Service = () => {
  return (
    <div className="justify-center align-center mt-6 md:pb-10 md:mb-14 mb-8 -pb-8">
      <div className="container mx-auto">
        <div className="text-center flex flex-col justify-center items-center mx-auto mb-4 mt-16">
          <p className="font-quicksand items-center font-bold text-2xl text-green mb-2">
            What We Do?
          </p>
          <h2 className=" font-quicksand font-bold md:text-5xl text-3xl md:-p-0 p-4 text-gray-600 mb-4 md:-mb-6   md:mt-6 mt-4">
            We believe that we can save more lives with you
          </h2>
        </div>
        <div className="services mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-16 mt-10 md:mt-24 md:p-7 p-6 md:ml-24 ">
          {services.map((service, index) => (
            <Link to={service.url} key={index}>
              <div className="col-lg-4 col-md-6">
                <div className=" flex items-center">
                  <div className=" mb-2">{service.icon}</div>
                  <div className="border-l-4 border-green rounded-lg ml-4 pl-4">
                    <h3 className="font-quicksand font-bold text-2xl text-gray-600 mb-2 ">
                      {service.title}
                    </h3>
                    <p className="mt-2 font-quicksand text-sm mb-4">
                      {service.description}
                    </p>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Service;
