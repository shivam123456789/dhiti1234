import { FaPhone } from 'react-icons/fa6';
import { MdEmail } from 'react-icons/md';
import { IoLocationSharp } from 'react-icons/io5';

const TopBar = () => {
  const googleMapsUrl = "https://www.google.com/maps";

  const openGoogleMaps = () => {
    window.open(googleMapsUrl, "_blank");
  };

  const ContactInfo = ({ icon, text, link }) => (
    <div className="flex items-center md:mb-5 md:ml-0 md:pt-0 pt-2 align-center md:justify-center md:flex-row md:h-16 px-10 text-center gap-2 hover:text-green" onClick={link && openGoogleMaps}>
      {icon}
      <a href={link} className="text-sm md:my-0 font-quicksand cursor-pointer hover:text-green">
        {text}
      </a>
    </div>
  );

  return (
    <div className="absolute bg-gray-100 md:h-16 w-full top-0 left-0 z-3 border-b border-opacity-30">
      <div className="container md:mx-auto">

          <div className="w-full flex flex-row md:mt-0 md:mb-0 md:flex md:flex-col">
            <div className="flex flex-col md:flex-row gap-2 items-center justify-around">
              <ContactInfo icon={<FaPhone className="text-green md:h-4 md:w-4 h-3 w-3 mr-1" />} text="+91 8871 xxxxxx" link="tel:+918871xxxxxx" />
              <ContactInfo icon={<MdEmail className="text-green md:h-4 md:w-4 w-3 h-3 mr-1" />} text="dhitifoundationfoundation@gmail.com" link="mailto:dhitifoundation@gmail.com" />
              <ContactInfo icon={<IoLocationSharp className="text-green md:h-4 md:w-4 w-3 h-3 mr-1" />} text="Bilaspur, Chhattisgarh" link={googleMapsUrl} />
            </div>
          </div>

      </div>
    </div>
  );
};

export default TopBar;
