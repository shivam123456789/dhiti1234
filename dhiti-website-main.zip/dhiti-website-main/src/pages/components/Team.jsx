import { HiBadgeCheck } from "react-icons/hi";
// import { useEffect, useRef } from 'react';
import Michael from "../../assets/team/Michael.png";
import Christopher from "../../assets/team/Christopher.png";
import Doris from "../../assets/team/Doris.png";
import Elorm from "../../assets/team/Elorm.png";
import Enam from "../../assets/team/Enam.png";
import Franklin from "../../assets/team/Franklin.png";
import Katahene from "../../assets/team/Katahene.png";
import Martha from "../../assets/team/Martha.png";
import Sitsofe from "../../assets/team/Sitsofe.png";
import William from "../../assets/team/William.png";
import George from "../../assets/team/George.png";
import Vincent from "../../assets/team/Vincent.png";
import Isaac from "../../assets/team/Isaac.png";
import { useInView } from "react-intersection-observer";

const teamData = [
  {
    name: "William Kojo Amoabeng",
    role: "Founder and President of RFI",
    role2: "Board Member",
    image: William,
    badge: <HiBadgeCheck />,
  },
  {
    name: "Doris Esinam Amoabeng",
    role: "CEO of Ambassadors Academy",
    role2: "Board Member",
    image: Doris,
    badge: <HiBadgeCheck />,
  },
  {
    name: "Dr. George Tesilimi Banji ",
    role: "Librarian and Lecturer at HTU",
    role2: "Board Member",
    image: George,
    badge: <HiBadgeCheck />,
  },
  {
    name: "Mrs. Sitsofe Kumoji",
    role: "Lecturer at Taviefe S.H.S",
    role2: "Board Member",
    image: Sitsofe,
    badge: <HiBadgeCheck />,
  },
  {
    name: "Mr. Mawuli Katahene",
    role: "Cheer Leader for MTN Ghana",
    role2: "Board Member",
    image: Katahene,
    badge: <HiBadgeCheck />,
  },
  {
    name: "Mrs. Martha Gato-Lagle",
    role: "Enterpreneur and Political Activist",
    role2: "Board Member",
    image: Martha,
    badge: <HiBadgeCheck />,
  },
  {
    name: "Vincent Kwasi Agbi",
    role: "Banker with Cal Bank, ",
    role2: "Board Member",
    image: Vincent,
    badge: <HiBadgeCheck />,
  },
  {
    name: "Christopher Kwame Heletsi",
    role: "Educationist at E.P Church",
    role2: "Board Member",
    image: Christopher,
    badge: <HiBadgeCheck />,
  },
  {
    name: "Isaac Kwasi Nyampong ",
    role: "Metallurgist in the Mining Industry",
    role2: "Board Member",
    image: Isaac,
    badge: <HiBadgeCheck />,
  },
  {
    name: "Kabanda Kpanti Michael",
    role: "IT Specialist / Software developer",
    role2: "Admin Team",
    image: Michael,
    badge: <HiBadgeCheck />,
  },
  {
    name: "Pastor Franklin Wunake",
    role: "Programmes and Events Speclialist",
    role2: "Admin Team",
    image: Franklin,
    badge: <HiBadgeCheck />,
  },
  {
    name: "Elorm Amoabeng",
    role: "Logistics Specialist",
    role2: "Admin Team",
    image: Elorm,
    badge: <HiBadgeCheck />,
  },
  {
    name: "Enam Amoabeng",
    role: "Protocol Specialist",
    role2: "Admin Team",
    image: Enam,
    badge: <HiBadgeCheck />,
  },
];

const Team = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  // const initialDisplayCount = 4;
  // const [displayCount, setDisplayCount] = React.useState(initialDisplayCount);

  // const handleViewMore = () => {
  //     setDisplayCount(displayCount + initialDisplayCount);
  // };

  return (
    <div className="justify-center align-center mt-8 pb-16">
      <div className="">
        <div className="text-center mx-auto mb-4 mt-24">
          <p className="font-quicksand items-center font-bold text-2xl text-green mb-2 ">
            Let's join us
          </p>
          <h2 className=" font-quicksand font-bold md:text-5xl text-3xl text-gray-600 mb-4 md:max-w-[700px] md:ml-[25%] mt-6 md:p-0 p-2">
            Your donation is a bridge to a brighter, hopeful future
          </h2>
        </div>
      </div>
      <div className="max-w-[85rem] px-4 py-10 sm:px-6 lg:px-8 lg:py-14 mx-auto">
        <div className="md:grid md:grid-cols-2 md:gap-10 lg:gap-16 md:items-center">
          <div className="hidden md:block mb-24 md:mb-0 sm:px-6">
            <div className="relative">
              <img
                className="rounded-xl"
                src="https://media.licdn.com/dms/image/C5622AQGV2fdQhDu18g/feedshare-shrink_1280/0/1642528784777?e=1712793600&v=beta&t=R4NuXb57vaEMNC6bgbrmFZcLMm2J02utYTDwY3KvWgQ"
                alt="Image Description"
              />

              <div className="absolute bottom-0 start-0 -z-[1] translate-y-10 -translate-x-14">
                <svg
                  className="max-w-40 h-auto text-slate-400 dark:text-slate-700"
                  width="696"
                  height="653"
                  viewBox="0 0 696 653"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <circle cx="72.5" cy="29.5" r="29.5" fill="currentColor" />
                  <circle cx="171.5" cy="29.5" r="29.5" fill="currentColor" />
                  <circle cx="270.5" cy="29.5" r="29.5" fill="currentColor" />
                  <circle cx="369.5" cy="29.5" r="29.5" fill="currentColor" />
                  <circle cx="468.5" cy="29.5" r="29.5" fill="currentColor" />
                  <circle cx="567.5" cy="29.5" r="29.5" fill="currentColor" />
                  <circle cx="666.5" cy="29.5" r="29.5" fill="currentColor" />
                  <circle cx="29.5" cy="128.5" r="29.5" fill="currentColor" />
                  <circle cx="128.5" cy="128.5" r="29.5" fill="currentColor" />
                  <circle cx="227.5" cy="128.5" r="29.5" fill="currentColor" />
                  <circle cx="326.5" cy="128.5" r="29.5" fill="currentColor" />
                  <circle cx="425.5" cy="128.5" r="29.5" fill="currentColor" />
                  <circle cx="524.5" cy="128.5" r="29.5" fill="currentColor" />
                  <circle cx="623.5" cy="128.5" r="29.5" fill="currentColor" />
                  <circle cx="72.5" cy="227.5" r="29.5" fill="currentColor" />
                  <circle cx="171.5" cy="227.5" r="29.5" fill="currentColor" />
                  <circle cx="270.5" cy="227.5" r="29.5" fill="currentColor" />
                  <circle cx="369.5" cy="227.5" r="29.5" fill="currentColor" />
                  <circle cx="468.5" cy="227.5" r="29.5" fill="currentColor" />
                  <circle cx="567.5" cy="227.5" r="29.5" fill="currentColor" />
                  <circle cx="666.5" cy="227.5" r="29.5" fill="currentColor" />
                  <circle cx="29.5" cy="326.5" r="29.5" fill="currentColor" />
                  <circle cx="128.5" cy="326.5" r="29.5" fill="currentColor" />
                  <circle cx="227.5" cy="326.5" r="29.5" fill="currentColor" />
                  <circle cx="326.5" cy="326.5" r="29.5" fill="currentColor" />
                  <circle cx="425.5" cy="326.5" r="29.5" fill="currentColor" />
                  <circle cx="524.5" cy="326.5" r="29.5" fill="currentColor" />
                  <circle cx="623.5" cy="326.5" r="29.5" fill="currentColor" />
                  <circle cx="72.5" cy="425.5" r="29.5" fill="currentColor" />
                  <circle cx="171.5" cy="425.5" r="29.5" fill="currentColor" />
                  <circle cx="270.5" cy="425.5" r="29.5" fill="currentColor" />
                  <circle cx="369.5" cy="425.5" r="29.5" fill="currentColor" />
                  <circle cx="468.5" cy="425.5" r="29.5" fill="currentColor" />
                  <circle cx="567.5" cy="425.5" r="29.5" fill="currentColor" />
                  <circle cx="666.5" cy="425.5" r="29.5" fill="currentColor" />
                  <circle cx="29.5" cy="524.5" r="29.5" fill="currentColor" />
                  <circle cx="128.5" cy="524.5" r="29.5" fill="currentColor" />
                  <circle cx="227.5" cy="524.5" r="29.5" fill="currentColor" />
                  <circle cx="326.5" cy="524.5" r="29.5" fill="currentColor" />
                  <circle cx="425.5" cy="524.5" r="29.5" fill="currentColor" />
                  <circle cx="524.5" cy="524.5" r="29.5" fill="currentColor" />
                  <circle cx="623.5" cy="524.5" r="29.5" fill="currentColor" />
                  <circle cx="72.5" cy="623.5" r="29.5" fill="currentColor" />
                  <circle cx="171.5" cy="623.5" r="29.5" fill="currentColor" />
                  <circle cx="270.5" cy="623.5" r="29.5" fill="currentColor" />
                  <circle cx="369.5" cy="623.5" r="29.5" fill="currentColor" />
                  <circle cx="468.5" cy="623.5" r="29.5" fill="currentColor" />
                  <circle cx="567.5" cy="623.5" r="29.5" fill="currentColor" />
                  <circle cx="666.5" cy="623.5" r="29.5" fill="currentColor" />
                </svg>
              </div>
            </div>
          </div>

          <div>
            <blockquote className="relative">
              <svg
                className="absolute top-0 start-0 transform -translate-x-8 -translate-y-4 size-24 text-gray-200 dark:text-gray-700"
                width="16"
                height="16"
                viewBox="0 0 16 16"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                aria-hidden="true"
              >
                {/* SVG path here */}
              </svg>

              <div className="relative z-10">
                <p className="text-xs font-semibold text-gray-500 tracking-wide uppercase mb-3 dark:text-gray-200">
                  Let&apos;s join with Dhiti Foundation
                </p>
                <p className="text-xl font-medium italic text-gray-800 md:text-2xl md:leading-normal xl:text-3xl xl:leading-normal dark:text-gray-200">
                  Your smallest contribution can bring water, increase incomes,
                  build toilets or light up homes in the remotest villages in
                  India. Choose your cause.
                </p>
              </div>

              <footer className="mt-6">
                <div className="flex items-center">
                  <div className="md:hidden flex-shrink-0 max-w-full">
                    <img
                      className="mt-4 w-full max-w-[100%] sm:max-w-[20%] mb-4"
                      src="https://media.licdn.com/dms/image/C5622AQGV2fdQhDu18g/feedshare-shrink_1280/0/1642528784777?e=1712793600&v=beta&t=R4NuXb57vaEMNC6bgbrmFZcLMm2J02utYTDwY3KvWgQ"
                      alt="Image Description"
                    />
                  </div>
                </div>
              </footer>

              <div className="mt-8 lg:mt-14">
                <a
                  className="py-3 px-4 inline-flex items-center gap-x-2 text-sm font-semibold rounded-lg border border-transparent bg-gray-800 text-white hover:bg-gray-900 disabled:opacity-50 disabled:pointer-events-none dark:bg-white dark:text-gray-800 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600"
                  href="#"
                >
                  Let&apos;s Donate
                </a>
              </div>
            </blockquote>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Team;
