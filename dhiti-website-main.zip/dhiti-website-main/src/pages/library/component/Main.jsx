import React from 'react';

// import Slider from "react-slick";

// import "slick-carousel/slick/slick.css";

// import "slick-carousel/slick/slick-theme.css";

// import { CIcon } from '@coreui/icons-react';



import CIcon from '@coreui/icons-react';

import { cilEnvelopeOpen } from '@coreui/icons';

// import ReactDOM from 'react-dom';
import "react-responsive-carousel/lib/styles/carousel.min.css";
// import { Carousel } from 'react-responsive-carousel';
import Carousels from './Carousels';


const Main = () => {


    const data = [
        {
            heading: "hi i am raj 1",
            url: "https://www.gramvikas.org/wp-content/themes/gramvikas/img/history/History_1st_Decade_1980_Biogas.jpg",

        }, {
            heading: "hi i am raj 2",
            url: "https://www.gramvikas.org/wp-content/themes/gramvikas/img/history/History_1st_Decade_1980_Biogas.jpg",
        },
        {
            heading: "hi i am raj 3",
            url: "https://www.gramvikas.org/wp-content/themes/gramvikas/img/history/History_1st_Decade_1980_Biogas.jpg",

        }, {
            heading: "hi i am raj 4",
            url: "https://www.gramvikas.org/wp-content/themes/gramvikas/img/history/History_1st_Decade_1980_Biogas.jpg",

        }, {
            heading: "hi i am raj 5",
            url: "https://www.gramvikas.org/wp-content/themes/gramvikas/img/history/History_1st_Decade_1980_Biogas.jpg",

        }, {
            heading: "hi i am raj 6",
            url: "https://www.gramvikas.org/wp-content/themes/gramvikas/img/history/History_1st_Decade_1980_Biogas.jpg",

        },
    ]

    const publication = [
        {
            img: "https://www.gramvikas.org/wp-content/uploads/2021/10/Gram-Vikas-COVID-Response-Second-Wave-Report-Sept-2021_001.jpg",
            des: "Mauris et lorem at elit tristique dignissim et ullamcorper elit. In sed feugiat mi. Etiam ut lacinia dui.",

        }, {
            img: "https://www.gramvikas.org/wp-content/uploads/2021/09/TEMPLET-library-design-1.jpg",
            des: "Mauris et lorem at elit tristique dignissim et ullamcorper elit. In sed feugiat mi. Etiam ut lacinia dui.",
        }, {
            img: "https://www.gramvikas.org/wp-content/uploads/2021/09/Baliguda.jpg",
            des: "Mauris et lorem at elit tristique dignissim et ullamcorper elit. In sed feugiat mi. Etiam ut lacinia dui.",
        }, {
            img: "https://www.gramvikas.org/wp-content/uploads/2021/08/TEMPLET-library-design.jpg",
            des: "Mauris et lorem at elit tristique dignissim et ullamcorper elit. In sed feugiat mi. Etiam ut lacinia dui.",
        }, {
            img: "https://www.gramvikas.org/wp-content/uploads/2021/08/TEMPLET-library-emory.jpg",
            des: "Mauris et lorem at elit tristique dignissim et ullamcorper elit. In sed feugiat mi. Etiam ut lacinia dui.",
        }, {
            img: "https://www.gramvikas.org/wp-content/uploads/2021/08/TEMPLET-library-emory.jpg",
            des: "Mauris et lorem at elit tristique dignissim et ullamcorper elit. In sed feugiat mi. Etiam ut lacinia dui.",
        }
    ]

    // var settings = {
    //     dots: true,
    //     infinite: true,
    //     speed: 1000,
    //     slidesToShow: 1,
    //     slidesToScroll: 1,
    //     autoplay: true,
    //     autoplaySpeed: 1500,
    // };



    return (
        <>
        <div>
            {/* <div className='xl:max-w-screen-xl font-quicksand pt-6 md:pt-12 pb-6 lg:pb-10 mx-auto px-6 sm:px-6 md:px-8 lg:px-12 xl:pt-24  '>
             */}
                {/* <Slider {...settings} className='flex justify-center items-center'>
                    {data.map((result) => (
                        <div key={result.id} className='flex justify-center items-center'>
                            <img src={result.url} alt="" />
                            <h2>{result.heading}</h2>
                        </div>
                    ))}
                </Slider> */}
                
                {/* <Carousel>

                    {data.map((result) => (
                        <div key={result.id} className='flex justify-center items-center'>
                            <img src={result.url} alt="" />
                            <h2>{result.heading}</h2>

                        </div>
                        
                    ))}

                </Carousel> */}
                <Carousels/>
               
                


            </div>
            {/* <div className='container '> */}
            <div class="xl:max-w-screen-xl font-quicksand pt-6 md:pt-12 pb-6 lg:pb-10 mx-auto px-6 sm:px-6 md:px-8 lg:px-12 xl:pt-24  ">
                <h4 class=" lg:text-3xl xl:text-5xl font-bold mb-6 text-gray-900 md:text-5xl text-4xl">
                    OUR ETHOS & CULTURE
                </h4>


                <div className='grid lg:grid-cols-3 xl:grid-cols-3 md:grid-cols-1 ms:grid-cols-1 cursor-pointer'>

                    {publication.map((result) => (
                        <div class="max-w-xs p-6 rounded-md shadow-md dark:bg-gray-900 dark:text-gray-50 hover:text-green m-5">
                            <img src={result.img} alt="" class="object-cover object-center w-full rounded-md h-72 dark:bg-gray-500" />
                            <div class="mt-6 mb-2">
                                {/* <CIcon icon={cilFilePdf} /> */}
                                <CIcon icon={cilEnvelopeOpen} className='w-9 h-9 m-2' />

                                <span class="block text-xs font-medium tracking-widest uppercase dark:text-violet-400">Quisque</span>
                                {/* <h2 class="text-xl font-semibold tracking-wide">Nam maximus purus</h2> */}
                            </div>
                            <p class="dark:text-gray-100">{result.des}</p>
                        </div>
                    ))}

                </div>




            </div>




        </>
    );

};

export default Main;