import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from 'react-responsive-carousel';
import Image1 from '../../../assets/child-dhiti2.jpeg';
import Image2 from '../../../assets/child-dhiti.jpeg';
import Image3 from '../../../assets/child-dhiti3.jpeg';
import Image4 from '../../../assets/blog/blog3.jpeg';
import { Link } from 'react-router-dom';
import { GoArrowRight } from 'react-icons/go';

const carouselItems = [
    {
        image: Image1,
        title: "Join Our Mission",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat odit vero aspernatur nostrum eligendi, magnam sunt hic ut in nesciunt ratione blanditiis sapiente excepturi suscipit, eum consequuntur omnis, fugiat est veniam cum illo? Quam consectetur hic praesentium rerum obcaecati quisquam provident quod id, nostrum qui architecto iusto dolorem enim eligendi placeat? Nulla ullam eveniet praesentium similique ex aperiam quos voluptatum voluptate ipsa error officia aliquid maiores magni obcaecati repudiandae recusandae quaerat, quidem iste cum soluta molestias eos fugit! Eligendi tempora possimus harum doloremque cum labore. Repudiandae omnis numquam libero nostrum? Molestias officiis sequi alias illum commodi tenetur a cupiditate voluptates.",
        buttonText: "Get Involved",
        // link: "/whyus/vision-and-approach"
    },
    {
        image: Image1,
        title: "Discover Our Initiatives",
        description: "LLorem ipsum dolor sit amet consectetur adipisicing elit. Placeat odit vero aspernatur nostrum eligendi, magnam sunt hic ut in nesciunt ratione blanditiis sapiente excepturi suscipit, eum consequuntur omnis, fugiat est veniam cum illo? Quam consectetur hic praesentium rerum obcaecati quisquam provident quod id, nostrum qui architecto iusto dolorem enim eligendi placeat? Nulla ullam eveniet praesentium similique ex aperiam quos voluptatum voluptate ipsa error officia aliquid maiores magni obcaecati repudiandae recusandae quaerat, quidem iste cum soluta molestias eos fugit! Eligendi tempora possimus harum doloremque cum labore. Repudiandae omnis numquam libero nostrum? Molestias officiis sequi alias illum commodi tenetur a cupiditate voluptates.",
        buttonText: "Learn More",
        // link: "/whyus/vision-and-approach"
    },
    {
        image: Image3,
        title: "Make a Difference",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat odit vero aspernatur nostrum eligendi, magnam sunt hic ut in nesciunt ratione blanditiis sapiente excepturi suscipit, eum consequuntur omnis, fugiat est veniam cum illo? Quam consectetur hic praesentium rerum obcaecati quisquam provident quod id, nostrum qui architecto iusto dolorem enim eligendi placeat? Nulla ullam eveniet praesentium similique ex aperiam quos voluptatum voluptate ipsa error officia aliquid maiores magni obcaecati repudiandae recusandae quaerat, quidem iste cum soluta molestias eos fugit! Eligendi tempora possimus harum doloremque cum labore. Repudiandae omnis numquam libero nostrum? Molestias officiis sequi alias illum commodi tenetur a cupiditate voluptates.",
        buttonText: "Donate Now",
        // link: "/whyus/vision-and-approach"
    },
    {
        image: Image4,
        title: "Spread Kindness",
        description: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat odit vero aspernatur nostrum eligendi, magnam sunt hic ut in nesciunt ratione blanditiis sapiente excepturi suscipit, eum consequuntur omnis, fugiat est veniam cum illo? Quam consectetur hic praesentium rerum obcaecati quisquam provident quod id, nostrum qui architecto iusto dolorem enim eligendi placeat? Nulla ullam eveniet praesentium similique ex aperiam quos voluptatum voluptate ipsa error officia aliquid maiores magni obcaecati repudiandae recusandae quaerat, quidem iste cum soluta molestias eos fugit! Eligendi tempora possimus harum doloremque cum labore. Repudiandae omnis numquam libero nostrum? Molestias officiis sequi alias illum commodi tenetur a cupiditate voluptates.",
        buttonText: "Volunteer Today",
        // link: "/whyus/vision-and-approach"
    },
];

const Hero = () => {
    return (
        <>
        <div className="-mt-2 relative w-full">
            <Carousel
                autoPlay={true}
                infiniteLoop={true}
                showArrows={false}
                showStatus={false}
                showThumbs={false}
                draggable={true}
                swipeScrollTolerance={3}
                stopOnHover={true}
            >
                {carouselItems.map((item, index) => (
                    <div key={index} className="relative  grid grid-cols-1 xl:grid-cols-2 items-center  m-10">
                        <div className="carousel-img relative  h-[25rem] sm:h-[35rem] md:h-[35rem] lg:h-120 xl:h-[35rem] text-right overflow-hidden">
                            <img src={item.image} alt="Image" className="object-center object-fit object-cover h-full" />
                            <div className="absolute top-0 left-0 w-full h-full bg-black opacity-70 z-10"></div>
                        </div>
                        <div className=" pl-[10%] carousel-text text-align-left flex flex-col items-start z-20 left-0">
                            <h1 className="font-raleway text-black text-2xl md:text-5xl font-bold mb-2 tracking-wide leading-tight">
                                {item.title}
                            </h1>
                            <p className="text-black font-quicksand md:text-xl text-left mb-4 ">
                                {item.description}
                            </p>
                            <Link to={item.link} className="p-2 text-sm jus md:text-md flex items-center text-center md:items-center md:text-center bg-green hover:bg-primary md:p-3 text-white font-quicksand mb-2 rounded-md cursor-pointer ">
                                {item.buttonText}
                                <GoArrowRight className="ml-2" />
                            </Link>
                        </div>
                    </div>
                ))}
            </Carousel>
        </div>


        {/* <div class="xl:max-w-screen-xl font-quicksand pt-6 md:pt-12 pb-6 lg:pb-10 mx-auto px-6 sm:px-6 md:px-8 lg:px-12 xl:pt-24  ">
                <h4 class=" lg:text-3xl xl:text-5xl font-bold mb-6 text-gray-900 md:text-5xl text-4xl">
                    OUR ETHOS & CULTURE
                </h4>


                <div className='grid lg:grid-cols-3 xl:grid-cols-3 md:grid-cols-1 ms:grid-cols-1 cursor-pointer'>

                    {publication.map((result) => (
                        <div class="max-w-xs p-6 rounded-md shadow-md dark:bg-gray-900 dark:text-gray-50 hover:text-green m-5">
                            <img src={result.img} alt="" class="object-cover object-center w-full rounded-md h-72 dark:bg-gray-500" />
                            <div class="mt-6 mb-2">
                               
                                <CIcon icon={cilEnvelopeOpen} className='w-9 h-9 m-2' />

                                <span class="block text-xs font-medium tracking-widest uppercase dark:text-violet-400">Quisque</span>
                               
                            </div>
                            <p class="dark:text-gray-100">{result.des}</p>
                        </div>
                    ))}

                </div>




            </div> */}
            
        </>

    );
};
export default Hero;


