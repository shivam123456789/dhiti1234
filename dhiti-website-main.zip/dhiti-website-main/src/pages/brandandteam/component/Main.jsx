import { HiBadgeCheck } from "react-icons/hi";
// import { useEffect, useRef } from 'react';
import Michael from '../../../assets/team/Michael.png';
import Christopher from '../../../assets/team/Christopher.png';
import Doris from '../../../assets/team/Doris.png';
import Elorm from '../../../assets/team/Elorm.png';
import Enam from '../../../assets/team/Enam.png';
import Franklin from '../../../assets/team/Franklin.png';
import Katahene from '../../../assets/team/Katahene.png';
import Martha from '../../../assets/team/Martha.png';
import Sitsofe from '../../../assets/team/Sitsofe.png';
import William from '../../../assets/team/William.png';
import George from '../../../assets/team/George.png';
import Vincent from '../../../assets/team/Vincent.png';
import Isaac from '../../../assets/team/Isaac.png';
import { useInView } from "react-intersection-observer";
import { useState } from 'react';

// import {
//     Tabs,
//     TabsHeader,
//     TabsBody,
//     Tab,
//     TabPanel,
// } from "@material-tailwind/react";

const teamData = [
    {
        name: 'William Kojo Amoabeng',
        role: "Founder and President of RFI",
        role2: "Board Member",
        image: William,
        badge: <HiBadgeCheck />,
    },
    {
        name: 'Doris Esinam Amoabeng',
        role: "CEO of Ambassadors Academy",
        role2: "Board Member",
        image: Doris,
        badge: <HiBadgeCheck />,
    },
    {
        name: 'Dr. George Tesilimi Banji ',
        role: "Librarian and Lecturer at HTU",
        role2: "Board Member",
        image: George,
        badge: <HiBadgeCheck />,
    },
    {
        name: 'Mrs. Sitsofe Kumoji',
        role: "Lecturer at Taviefe S.H.S",
        role2: "Board Member",
        image: Sitsofe,
        badge: <HiBadgeCheck />,
    },
    {
        name: 'Mr. Mawuli Katahene',
        role: "Cheer Leader for MTN Ghana",
        role2: "Board Member",
        image: Katahene,
        badge: <HiBadgeCheck />,
    },
    {
        name: 'Mrs. Martha Gato-Lagle',
        role: "Enterpreneur and Political Activist",
        role2: "Board Member",
        image: Martha,
        badge: <HiBadgeCheck />,
    },
    {
        name: 'Vincent Kwasi Agbi',
        role: "Banker with Cal Bank, ",
        role2: "Board Member",
        image: Vincent,
        badge: <HiBadgeCheck />,
    },
    {
        name: 'Christopher Kwame Heletsi',
        role: "Educationist at E.P Church",
        role2: "Board Member",
        image: Christopher,
        badge: <HiBadgeCheck />,
    },
    {
        name: 'Isaac Kwasi Nyampong ',
        role: "Metallurgist in the Mining Industry",
        role2: "Board Member",
        image: Isaac,
        badge: <HiBadgeCheck />,
    },
    {
        name: 'Kabanda Kpanti Michael',
        role: "IT Specialist / Software developer",
        role2: "Admin Team",
        image: Michael,
        badge: <HiBadgeCheck />,
    },
    {
        name: 'Pastor Franklin Wunake',
        role: "Programmes and Events Speclialist",
        role2: "Admin Team",
        image: Franklin,
        badge: <HiBadgeCheck />,
    },
    {
        name: 'Elorm Amoabeng',
        role: "Logistics Specialist",
        role2: "Admin Team",
        image: Elorm,
        badge: <HiBadgeCheck />,
    },
    // {
    //     name: 'Enam Amoabeng',
    //     role: "Protocol Specialist",
    //     role2: "Admin Team",
    //     image: Enam,
    //     badge: <HiBadgeCheck />,
    // },
];

const Main = () => {

    const [ref, inView] = useInView({
        triggerOnce: true,
        threshold: 0.1,
    });
    


    // const [activeTab, setActiveTab] = React.useState("mission");

    // const data = [
    //     {
    //         label: "Mission",
    //         value: "mission",
    //         desc: `Ministering to the needs of the young person and restoring them to their divine destiny`,
    //     },
    //     {
    //         label: "Vision",
    //         value: "vision",
    //         desc: `To develop a community of friendship, personal fulfillment and recreation for all participants`,
    //     },
    //     {
    //         label: "Values",
    //         value: "core-values",
    //         desc: `We are divinely Chosen to Share and Share. Donors, Board, Staff, Volunteers and Beneficiaries are set for social development
    //         and re-orientation. We respect each individual's dignity and uniqueness`,
    //     },
    // ];



    return (
        <>
            <div className='justify-center align-center mt-8 pb-16'>


                {/* <Tabs value={activeTab} className='md:ml-0 -ml-8 md:mb-0 -mb-14'>
                    <TabsHeader
                        className="rounded-none border-b border-blue-gray-50 bg-transparent p-0 mt-4"
                        indicatorProps={{
                            className:
                                "bg-transparent border-b-2 border-green shadow-none rounded-none",
                        }}
                    >
                        {data.map(({ label, value }) => (
                            <Tab
                                key={value}
                                value={value}
                                onClick={() => setActiveTab(value)}
                                className={activeTab === value ? "text-gray-900 md:text-lg text-lg font-quicksand font-semibold text-green" : "font-quicksand text-lg font-semibold"}
                            >
                                {label}
                            </Tab>
                        ))}
                    </TabsHeader>
                    <TabsBody>
                        {data.map(({ value, desc }) => (
                            <TabPanel key={value} value={value} className="font-quicksand md:text-md text-sm">
                                {desc}
                            </TabPanel>
                        ))}
                    </TabsBody>
                </Tabs> */}
                
                <div className="flex justify-center p-2 mt-8 relative">
                    <div
                        ref={ref}
                        className={`grid md:grid-cols-4 grid-cols-1 gap-4 `}>
                        {teamData.map((team, index) => (
                            <div key={index}
                                className={`m-4 rounded-md relative pb-16 ${inView ? "zoom-in zoom-in-animation-active" : ""} `}  >
                                <img src={team.image} alt={`Team-${index + 1}`} className="w-full h-full object-cover object-center rounded-md" />
                                <div className="w-[70%] shadow-lg h-32 absolute bottom-0 left-1/2 pb-8 transform -translate-x-1/2 bg-white border-green border-b-4 rounded-md text-center">
                                    <h2 className=' font-quicksand mt-4 text-sm font-bold'>{team.name}</h2>
                                    <div className='flex items-center justify-center mt-3 '>
                                        <p className='font-quicksand font-medium text-sm text-gray-600'>{team.role2}</p>
                                        <p className='ml-4 items-center text-green'>{team.badge}</p>
                                    </div>
                                    <p className='mt-3 font-quicksand text-xs font-medium text-gray-600'>{team.role}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>


            </div>


            <section class="m-4 md:m-8 dark:bg-gray-800 dark:text-gray-100 ">
                <div class="container p-4 mx-auto  my-6 space-y-1 text-center ">
                    {/* <span class="text-md font-quicksand font-semibold tracking-wider uppercase text-green">Partners</span> */}
                    <h2 class="pb-3 text-3xl float-start font-bold md:text-4xl  under text-green">PARTNERS</h2>
                    {/* <p>Get a jumpstart to creating your new webpage! With our fully responsive and carefully styled components you can get the structure of your website done with just a couple of clicks.</p> */}
                </div>
                <div class="container grid justify-spacebetween  lg:grid-cols-1 xl:grid-cols-3 sm:grid-cols-1 md:grid-cols-1 ">
                    {/* <div class="flex flex-col px-8 py-6">
                        <h2 class="mb-2 text-lg font-semibold sm:text-xl title-font dark:text-gray-100">Components</h2>
                        <p class="flex-1 mb-4 text-base leading-relaxed dark:text-gray-400">Individual components that can be re-used multiple times in your designs.</p>
                        <a class="inline-flex items-center space-x-2 text-sm dark:text-violet-400" href="/components">
                            <span>Learn More</span>
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-4 h-4">
                                <path fill-rule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                            </svg>
                        </a>
                    </div> */}
                    <div class="flex flex-col px-8 py-6 ">
                        <h2 class="mb-2 text-lg font-semibold sm:text-xl title-font dark:text-gray-100    ">Doner</h2>
                        <p class="flex-1 mb-4 text-base leading-relaxed dark:text-gray-400">Our donors are corporates, foundations, bilateral agencies and individual philanthropists, who support solutions across our diverse areas of work and institutional developmentPre-made building blocks that you can stack on top of each other like Legos to build a website of your own in minutes.</p>
                        <a class="inline-flex items-center space-x-2 text-sm  text-green" href="/partner">
                            <span>Learn More</span>
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-4 h-4">
                                <path fill-rule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                            </svg>
                        </a>
                    </div>
                    <div class="flex flex-col px-8 py-6">
                        <h2 class="mb-2 text-lg font-semibold sm:text-xl title-font dark:text-gray-100">Government </h2>
                        <p class="flex-1 mb-4 text-base leading-relaxed dark:text-gray-400">Long and synergistic partnerships with state and national governments help us achieve scale and maximise the reach of benefits among the rural poor.</p>
                        <a class="inline-flex items-center space-x-2 text-sm text-green" href="/partner">
                            <span>Learn More</span>
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-4 h-4">
                                <path fill-rule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                            </svg>
                        </a>
                    </div>
                    <div class="flex flex-col px-8 py-6">
                        <h2 class="mb-2 text-lg font-semibold sm:text-xl title-font dark:text-gray-100">Knowledge Parners</h2>
                        <p class="flex-1 mb-4 text-base leading-relaxed dark:text-gray-400">Collaborations with knowledge partners support technology solutions, improved service delivery and capacity building of teams and local institutions.</p>
                        <a class="inline-flex items-center space-x-2 text-sm text-green" href="/partner">
                            <span>Learn More</span>
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="w-4 h-4">
                                <path fill-rule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                            </svg>
                        </a>
                    </div>
                </div>
            </section>
        </>
    );
};

export default Main;