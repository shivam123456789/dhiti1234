import React from "react";
import Main from "../components/Main";
import Header from "../components/Header";
import Navigation from "../../components/Navigation";
import Spinner from "../../components/Spinner";
import Footer from "../../components/Footer";
import ScrollToTop from "../../components/Scroll";

import { useParams } from "react-router-dom";

const Project = () => {
    let { category } = useParams();
  return (
    <>
      <div>
        <Navigation />
        <Header title={category} />
        <Main/>
        <Footer />
        <ScrollToTop />
      </div>
      {/* <Routes>
      <Route path={`/water/blog`} element={<Spinner />} />
    </Routes> */}
    </>
  );
};

export default Project;
