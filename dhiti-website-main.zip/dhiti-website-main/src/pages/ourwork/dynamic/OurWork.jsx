import React, { useEffect, useState } from "react";
import { useData } from '../../../context/DataContext';
import { useParams } from "react-router-dom";
import { fetchProjects } from "../../../utils/fetch";
import Header from "../components/Header";
import Navigation from "../../components/Navigation";
import Spinner from "../../components/Spinner";
import Footer from "../../components/Footer";
import ScrollToTop from "../../components/Scroll";
import Card from "../components/Card";
import Skeleton from "../components/Skeleton";

const OurWork = () => {
  let { category } = useParams();
  const { setDataContext } = useData();
  const [data, setData] = useState([]);
  const [loader, setLoader] = useState(false);
  const [error, setError] = useState("");
  const [filterType, setFilterType] = useState("all");

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoader(true);
        let res = await fetchProjects(category);
        setData(res.data);
        console.log(data);
        localStorage.setItem("project", JSON.stringify(res.data));
        setLoader(false);
      } catch (error) {
        console.error(error);
        setError("Failed to fetch projects. Please try again later.");
        setLoader(false);
      }
    };

    fetchData();
    console.log(data);
  }, [category]);

  useEffect(() => {
    console.log(data); // This will log every time `data` changes.
  }, [data]);

  const filteredData = data.filter((project) => {
    if (filterType === "completed") {
      return project.completed_status;
    } else if (filterType === "not_completed") {
      return !project.completed_status;
    }
    return true;
  });

  return (
    <>
      <div>
        <Navigation />
        <Header title={category || "Projects"} />
        <div className="mt-24 mb-4 mx-5 flex flex-col items-center">
          <div className="mb-4 flex gap-2">
            <button
              onClick={() => setFilterType("all")}
              className={`px-4 py-2 rounded-md ${
                filterType === "all" ? "bg-green-500 text-black" : "bg-gray-200"
              }`}
            >
              Show All Projects
            </button>
            <button
              onClick={() => setFilterType("completed")}
              className={`px-4 py-2 rounded-md ${
                filterType === "completed"
                  ? "bg-green-500 text-black"
                  : "bg-gray-200"
              }`}
            >
              Show Completed Projects
            </button>
            <button
              onClick={() => setFilterType("not_completed")}
              className={`px-4 py-2 rounded-md ${
                filterType === "not_completed"
                  ? "bg-green-500 text-black"
                  : "bg-gray-200"
              }`}
            >
              Show Not Completed Projects
            </button>
          </div>
          <div className="flex gap-3 flex-wrap justify-center items-start">
            {loader ? (
              <>
                <Skeleton />
                <Skeleton />
                <Skeleton />
              </>
            ) : filteredData?.length !== 0 ? (
              filteredData.map((item, index) => (
                <Card
                  key={index}
                  title={item.heading}
                  description={item.description}
                  reach={item.reach_household}
                  partner={item.partner}
                  item={item}
                  imageUrl={item.img_url}
                />
              ))
            ) : error ? (
              <p>{error}</p>
            ) : (
              <p>No projects available</p>
            )}
          </div>
        </div>
        <Footer />
        <ScrollToTop />
      </div>
    </>
  );
};

export default OurWork;
