import React from "react";
import { Link } from "react-router-dom";
import { useData } from "../../../context/DataContext";

function paraMaker(para) {
  let description = para;
  const maxLength = Math.ceil(description.length / 2);
  let splitIndex = maxLength;

  // Check if the description contains a period or newline character
  for (let i = maxLength; i < description.length; i++) {
    if (description[i] === "." || description[i] === "\n") {
      splitIndex = i + 1; // Include the period or newline character
      break;
    }
  }

  // Split the description into two paragraphs
  let paragraph1 = description.substring(0, splitIndex);
  let paragraph2 = description.substring(splitIndex);

  return [paragraph1, paragraph2];
}

const Main = () => {
  const serializedArray = localStorage.getItem("item");
  let dataContext = JSON.parse(serializedArray);

  let description = paraMaker(dataContext.description);

  return (
    <div>
      <div className="mt-16 max-w-6xl px-4 pt-6 lg:pt-10 pb-12 sm:px-6 lg:px-8 mx-auto">
        <div className="max-w-6xl">
          <div className="space-y-5 md:space-y-8" style={{ whiteSpace: "pre-line" }}>
            <div className="space-y-3">
              <h2 className="text-2xl font-bold md:text-3xl dark:text-white">
                {dataContext
                  ? dataContext.heading
                  : "Announcing a free plan for small teams"}
              </h2>
              {/* <p className="text-lg text-gray-800 dark:text-gray-200">
                {description[0]}
              </p> */}
            </div>

            <figure className="flex justify-center">
              <img
                className="w-full max-w-full h-auto object-cover rounded-xl md:w-1/2"
                src={dataContext ? dataContext.img_url : "https://www.gramvikas.org/wp-content/uploads/2019/01/Water_Header_new-1.jpg"}
                alt="Image Description"
              />
            </figure>

            <p className="text-lg text-gray-800 dark:text-gray-200">
              {/* {description[1]} */}
              {dataContext?.description}
            </p>

            <div>
              <Link
                className="m-1 inline-flex items-center gap-1.5 py-2 px-3 rounded-full text-sm bg-gray-100 text-gray-800 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 dark:text-gray-200 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600"
                to={"/ourwork/education"}
              >
                Education
              </Link>
              <Link
                className="m-1 inline-flex items-center gap-1.5 py-2 px-3 rounded-full text-sm bg-gray-100 text-gray-800 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 dark:text-gray-200 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600"
                to={"/ourwork/youth-welfare"}
              >
                Youth and Welfare
              </Link>
              <Link
                className="m-1 inline-flex items-center gap-1.5 py-2 px-3 rounded-full text-sm bg-gray-100 text-gray-800 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 dark:text-gray-200 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600"
                to={"/ourwork/environment-one-health"}
              >
                Enviroment and One Health
              </Link>
              <Link
                className="m-1 inline-flex items-center gap-1.5 py-2 px-3 rounded-full text-sm bg-gray-100 text-gray-800 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 dark:text-gray-200 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600"
                to={"/ourwork/health-campaign"}
              >
                Health and Campaign
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Main;
