import React from "react";
import { useData } from "../../../context/DataContext";
import {useNavigate,useParams} from "react-router-dom";

const ProjectCard = ({
  imageUrl,
  title,
  description,
  reach,
  partner,
  item,
}) => {
  let { category } = useParams();
  const { setDataContext,dataContext } = useData();
  const navigate = useNavigate();

  if (!title) {
    title = "title";
  }
  if (!description) {
    description = "Here is the description Here here here here";
  }
  if (title){ 
  return (
    <div className="">
      <div class="relative flex flex-col mt-6 text-gray-700 bg-white shadow-md bg-clip-border rounded-xl w-96">
        <div class="relative h-56 mx-4 -mt-6 overflow-hidden text-white shadow-lg bg-clip-border rounded-xl bg-blue-gray-500 shadow-blue-gray-500/40">
          <img
            src={
              imageUrl
                ? imageUrl
                : "https://www.gramvikas.org/wp-content/uploads/2019/01/WATER_A.jpg"
            }
            alt="card-image"
          />
        </div>
        <div class="p-6">
          <h5 class="block mb-2 font-sans text-xl antialiased font-semibold leading-snug tracking-normal text-blue-gray-900">
            {title.length > 30 ? `${title.slice(0, 30)}...` : title}
          </h5>
          <p class="block font-sans text-base antialiased font-light leading-relaxed text-inherit">
            {description.length > 100
              ? `${description.slice(0, 100)}...`
              : description}
          </p>
        </div>
        <div className="p-6 pt-0 ">
          <ul className="flex ">
            <li className="flex-1">
              <h6 className="text-green">Reach</h6>
              <h5 className="text-sm max-w-32 ">{reach}</h5>
            </li>
            <li className="flex-1">
              <h6 className="text-green">Partners</h6>
              <h5 className="text-sm">{partner}</h5>
            </li>
          </ul>
        </div>

        <div class="p-6 pt-0">
          <button
            onClick={() => {
              setDataContext(item);
              localStorage.setItem("item", JSON.stringify(item));
              // navigate(`/ourwork/${category}/blog`)
              navigate(`/ourwork/project`)
              
            }}
            class="align-middle select-none font-sans font-bold text-center uppercase transition-all disabled:opacity-50 disabled:shadow-none disabled:pointer-events-none text-xs py-3 px-6 rounded-lg bg-gray-900 text-white shadow-md shadow-gray-900/10 hover:shadow-lg hover:shadow-gray-900/20 focus:opacity-[0.85] focus:shadow-none active:opacity-[0.85] active:shadow-none"
            type="button"
          >
            Read More
          </button>
        </div>
      </div>
    </div>
  );}else{
    return(<>
      <h1>Hello</h1>
    </>)
  }
};

export default ProjectCard;
