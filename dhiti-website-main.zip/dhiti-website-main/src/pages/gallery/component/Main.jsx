
const Main = () => {



    const myStyle = {
        height: '300px',
        width: '100%'
    };


    return (

        
        <div className=' w-full'>
            <section class="bg-white dark:bg-gray-900">
                <div class="gap-16 items-center py-8 px-4 mx-auto max-w-screen-xl lg:grid lg:grid-cols-2 lg:py-16 lg:px-6">
                    <div class=" text-black-500 sm:text-lg dark:text-gray-400">
                        <h2 class="mb-4 font-raleway text-4xl tracking-tight font-extrabold text-gray-900 dark:text-white">FROM OUR ANNUAL REPORT</h2>
                        <p class="mb-4">We are strategists, designers and developers. Innovators and problem solvers. Small enough to be simple and quick, but big enough to deliver the scope you want at the pace you need. Small enough to be simple and quick, but big enough to deliver the scope you want at the pace you need.</p>
                        <p>We are strategists, designers and developers. Innovators and problem solvers. Small enough to be simple and quick.</p>

                        <button class="bg-blue-500 hover:bg-blue-700 text-black my-10  font-bold py-2 px-7 border border-black-700 rounded active:bg-green active:text-white transform-500">
                            Download The Annual Report
                        </button>
                    </div>


                    <div class="grid grid-cols-2 gap-4 mt-8">
                        <img class="w-full rounded-lg" src="https://flowbite.s3.amazonaws.com/blocks/marketing-ui/content/office-long-2.png" alt="office content 1" />
                        <img class="mt-4 w-full lg:mt-10 rounded-lg" src="https://flowbite.s3.amazonaws.com/blocks/marketing-ui/content/office-long-1.png" alt="office content 2" />
                    </div>


                </div>



            </section>




            {/* <div className='justify-center align-center md:mt-6 -mt-4'>
                <div className=''>
                    <div className='text-center flex-col items-center justify-center mx-auto mb-4 mt-8'>
                        <p className="font-quicksand items-center font-bold text-2xl text-green mb-2 ">
                            Popular Causes
                        </p>
                        <h2 className=" font-quicksand text-center font-bold md:text-5xl text-3xl text-gray-600 mb-4 md:max-w-[800px] md:ml-[25%] mt-6 md:p-0 p-2">
                            Let us know about charity causes
                        </h2>
                    </div>
                </div>

                <div class="max-w-screen-xl mx-auto p-5 sm:p-10 md:p-16 relative">
                    <div class="bg-cover bg-center text-center overflow-hidden" style={myStyle}>

                        <img src="https://api.time.com/wp-content/uploads/2020/07/never-trumpers-2020-election-01.jpg" />
                    </div>

                </div>
                <div class="w-full max-w-3xl mx-auto">
                    <div
                        class="mt-3 bg-white rounded-b lg:rounded-b-none lg:rounded-r flex flex-col justify-between leading-normal">
                        <div class="bg-white relative top-0 -mt-32 p-5 sm:p-10">
                            <h1 href="#" class="text-gray-900 font-bold text-3xl mb-2">Revenge of the Never Trumpers</h1>
                            <p class="text-gray-700 text-xs mt-2">Written By:
                                <a href="#"
                                    class="text-indigo-600 font-medium hover:text-gray-900 transition duration-500 ease-in-out">
                                    Ahmad Sultani
                                </a> In
                                <a href="#"
                                    class="text-xs text-indigo-600 font-medium hover:text-gray-900 transition duration-500 ease-in-out">
                                    Election
                                </a>,
                                <a href="#"
                                    class="text-xs text-indigo-600 font-medium hover:text-gray-900 transition duration-500 ease-in-out">
                                    Politics
                                </a>

                            </p>

                            <p class="text-base leading-8 my-5">
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
                                industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type
                                and scrambled it to make a type specimen book. It has survived not only five centuries, but also the
                                leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s
                                with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop
                                publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                            </p>

                            <h3 class="text-2xl font-bold my-5">#1. What is Lorem Ipsum?</h3>

                            <p class="text-base leading-8 my-5">
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
                                industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type
                                and scrambled it to make a type specimen book. It has survived not only five centuries, but also the
                                leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s
                                with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop
                                publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                            </p>

                            <blockquote class="border-l-4 text-base italic leading-8 my-5 p-5 text-indigo-600">Lorem Ipsum is simply
                                dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard
                                dummy text ever since the 1500s
                            </blockquote>

                            <p class="text-base leading-8 my-5">
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
                                industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type
                                and scrambled it to make a type specimen book. It has survived not only five centuries, but also the
                                leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s
                                with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop
                                publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                            </p>


                            <a href="#"
                                class="text-xs text-indigo-600 font-medium hover:text-gray-900 transition duration-500 ease-in-out">
                                #Election
                            </a>,
                            <a href="#"
                                class="text-xs text-indigo-600 font-medium hover:text-gray-900 transition duration-500 ease-in-out">
                                #people
                            </a>,
                            <a href="#"
                                class="text-xs text-indigo-600 font-medium hover:text-gray-900 transition duration-500 ease-in-out">
                                #Election2020
                            </a>,
                            <a href="#"
                                class="text-xs text-indigo-600 font-medium hover:text-gray-900 transition duration-500 ease-in-out">
                                #trump
                            </a>,<a href="#"
                                class="text-xs text-indigo-600 font-medium hover:text-gray-900 transition duration-500 ease-in-out">
                                #Joe
                            </a>

                        </div>

                    </div>
                </div>
            </div> */}

            <div className='justify-center align-center md:mt-6 -mt-4'>
                <div className=''>
                    <div className='text-center flex-col items-center justify-center mx-auto mb-4 mt-8'>
                        <p className="font-quicksand items-center font-bold text-2xl text-green mb-2 ">
                            Popular Causes
                        </p>
                        <h2 className=" font-quicksand text-center font-bold md:text-5xl text-3xl text-gray-600 mb-4 md:max-w-[800px] md:ml-[25%] mt-6 md:p-0 p-2">
                            Let us know about charity causes
                        </h2>
                    </div>
                </div>

                <div class="max-w-screen-xl mx-auto p-5 sm:p-10 md:p-16 relative">
                    <div class="bg-cover bg-center text-center overflow-hidden" style={myStyle}>

                        <img src="https://api.time.com/wp-content/uploads/2020/07/never-trumpers-2020-election-01.jpg" />
                    </div>

                </div>
                <div class="w-full max-w-3xl mx-auto">
                    <div
                        class="mt-3 bg-white rounded-b lg:rounded-b-none lg:rounded-r flex flex-col justify-between leading-normal">
                        <div class="bg-white relative top-0 -mt-32 p-5 sm:p-10">
                            <h1 href="#" class="text-gray-900 font-bold text-3xl mb-2">WATER SECURE GRAM PANCHAYAT</h1>
                            {/* <p class="text-gray-700 text-xs mt-2">Written By:
                                <a href="#"
                                    class="text-indigo-600 font-medium hover:text-gray-900 transition duration-500 ease-in-out">
                                    Ahmad Sultani
                                </a> In
                                <a href="#"
                                    class="text-xs text-indigo-600 font-medium hover:text-gray-900 transition duration-500 ease-in-out">
                                    Election
                                </a>,
                                <a href="#"
                                    class="text-xs text-indigo-600 font-medium hover:text-gray-900 transition duration-500 ease-in-out">
                                    Politics
                                </a>

                            </p> */}
                            <h3 class="text-2xl font-bold my-5">Fostering community-led water resource management and gender equity</h3>

                            <p class="text-base leading-8 my-5">
                                The Water Secure Gram Panchayat (WSGP) programme, initiated by Gram Vikas in 2021, targets comprehensive community-led water resource management and sustainable, gender-equitable development in rural communities. Addressing challenges like water scarcity, climate change, and insufficient community capabilities, WSGP integrates various domains such as village institutions, water, sanitation, health, livelihoods, and technology. The program's multi-dimensional approach fosters collaboration between citizens and local governments, empowers women in decision-making, and utilises technology for natural resource productivity.
                            </p>

                            <h3 class="text-2xl font-bold my-5 px-1">PROGRESS DURING THE YEAR</h3>

                            <blockquote class="border-l-4 text-base italic leading-8 my-5 p-5 text-black-bold">
                                Successfully captured baseline information at Gram Panchayat, village, and household levels across 71 GPs

                                Reformed and formed new Village Development Committees, with ongoing capacity building for members

                            </blockquote>
                            <blockquote class="border-l-4 text-base italic leading-8 my-5 p-5 text-black-bold">
                                Successfully captured baseline information at Gram Panchayat, village, and household levels across 71 GPs

                                Reformed and formed new Village Development Committees, with ongoing capacity building for members

                            </blockquote>
                            <blockquote class="border-l-4 text-base italic leading-8 my-5 p-5 text-black-bold">
                                Successfully captured baseline information at Gram Panchayat, village, and household levels across 71 GPs

                                Reformed and formed new Village Development Committees, with ongoing capacity building for members

                            </blockquote>
                            <blockquote class="border-l-4 text-base italic leading-8 my-5 p-5 text-black-bold">
                                Successfully captured baseline information at Gram Panchayat, village, and household levels across 71 GPs

                                Reformed and formed new Village Development Committees, with ongoing capacity building for members

                            </blockquote>

                            <blockquote class="border-l-4 text-base italic leading-8 my-5 p-5 text-black-bold">Lorem Ipsum is simply
                                dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard
                                dummy text ever since the 1500s
                            </blockquote>

                            <h3 class="text-2xl font-bold my-5">DISTRICTS</h3>

                            <h3 className="font-bold ">Odisha</h3>
                            <p className="pb-5">Gajapati, Ganjam, Jharsuguda, Kalahandi, Kandhamal, Keonjhar, Mayurbhanj, Nayagarh, Sundargarh</p>

                            <h3 className="font-bold">Jharkhand

                            </h3>
                            <p>Gumla</p>





                            {/* <p class="text-base leading-8 my-5">
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the
                                industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type
                                and scrambled it to make a type specimen book. It has survived not only five centuries, but also the
                                leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s
                                with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop
                                publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                            </p> */}


                            {/* <a href="#"
                                class="text-xs text-indigo-600 font-medium hover:text-gray-900 transition duration-500 ease-in-out">
                                #Election
                            </a>,
                            <a href="#"
                                class="text-xs text-indigo-600 font-medium hover:text-gray-900 transition duration-500 ease-in-out">
                                #people
                            </a>,
                            <a href="#"
                                class="text-xs text-indigo-600 font-medium hover:text-gray-900 transition duration-500 ease-in-out">
                                #Election2020
                            </a>,
                            <a href="#"
                                class="text-xs text-indigo-600 font-medium hover:text-gray-900 transition duration-500 ease-in-out">
                                #trump
                            </a>,<a href="#"
                                class="text-xs text-indigo-600 font-medium hover:text-gray-900 transition duration-500 ease-in-out">
                                #Joe
                            </a> */}

                        </div>

                    </div>
                </div>
            </div>




            <div class="max-w-[85rem] px-4 py-10 sm:px-6 lg:px-8 lg:py-14 mx-auto">

                {/* <div class="max-w-2xl mx-auto text-center mb-10 lg:mb-14">
                    <h2 class="text-2xl font-bold md:text-3xl md:leading-tight text-gray-800 dark:text-gray-200">
                        Frequently Asked Questions
                    </h2>
                </div> */}


                <div class="max-w-5xl mx-auto">

                    <div class="grid sm:grid-cols-1 gap-6 md:gap-12 border border-solid border-red p-5">
                        <div>
                            <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-200">
                            Women became fish farmers to stand on their feet
                            </h3>
                            <p class="mt-2 text-gray-600 dark:text-gray-400">
                            Witness the inspiring journey of the women of Maa Saraswati Self Help Group in Gramadebati village, who reshaped their lives through successful fish cultivation. This story highlights their resilience and entrepreneurial spirit, from winning a pond lease bid to overcoming challenges and reaping the financial benefits of their collective effort in pisciculture. Read the story.
                            </p>
                        </div>


                        <div>
                            <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-200">
                            Migrant support centres help worker recover dues from their employer
                            </h3>
                            <p class="mt-2 text-gray-600 dark:text-gray-400">
                            Follow the journey of Abhiram Majhi, a migrant worker from Odisha, as he navigates challenges in his quest for work and fair treatment. This story highlights the crucial role of financial literacy, and the successful intervention by Gram Vikas that helped secure his and a fellow worker’s due wages, inspiring confidence among migrant workers. Read the story.
                            </p>
                        </div>


                        {/* <div>
                            <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-200">
                                How does Preline's pricing work?
                            </h3>
                            <p class="mt-2 text-gray-600 dark:text-gray-400">
                                Our subscriptions are tiered. Understanding the task at hand and ironing out the wrinkles is key.
                            </p>
                        </div>


                        <div>
                            <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-200">
                                How secure is Preline?
                            </h3>
                            <p class="mt-2 text-gray-600 dark:text-gray-400">
                                Protecting the data you trust to Preline is our first priority. This part is really crucial in keeping the project in line to completion.
                            </p>
                        </div> */}


                        {/* <div>
                            <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-200">
                                Do you offer discounts?
                            </h3>
                            <p class="mt-2 text-gray-600 dark:text-gray-400">
                                We've built in discounts at each tier for teams. The time has come to bring those ideas and plans to life.
                            </p>
                        </div> */}


                        {/* <div>
                            <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-200">
                                What is your refund policy?
                            </h3>
                            <p class="mt-2 text-gray-600 dark:text-gray-400">
                                We offer refunds. We aim high at being focused on building relationships with our clients and community.
                            </p>
                        </div> */}

                    </div>

                </div>
            </div>




        </div >

    );
};

export default Main;