import React from 'react';

import { useEffect, useState } from 'react';

import { useParams } from 'react-router-dom';

import Navigation from '../components/Navigation'

import Spinner from '../components/Spinner';
import Header from './component/Header';

const Project = (name) => {

    let {slug}=useParams();
     



    const [isLoading, setIsLoading] = useState(true);
    useEffect(() => {
        const timer = setTimeout(() => {
            setIsLoading(false);
        }, 1000);

        return () => {
            clearTimeout(timer);
        };
    }, []);


    return (
        <div>
        {isLoading ?
                <Spinner />
                :
                <div>
                    <Navigation 

                    />
                    <Header
                        heading = {` ${slug}`}
                        path = {'Water'}
                    />
                    
                </div>
            }

            

            
        </div>
    );
};

export default Project;