import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import Navigation from '../../../components/Navigation';
import Footer from '../../../components/Footer';
import ScrollToTop from '../../../components/Scroll';
import Spinner from '../../../components/Spinner'
import Main from './component/Main';
import Header from './component/Header';
import Blog from './component/Blog';

const Blog1 = () => {
    const location = useLocation();

    useEffect(() => {
        window.scrollTo(0, 0);
    }, [location]);

    const [isLoading, setIsLoading] = useState(true);
    useEffect(() => {
        const timer = setTimeout(() => {
            setIsLoading(false);
        }, 1000);

        return () => {
            clearTimeout(timer); // Clear the timeout when the component is unmounted or the dependency changes
        };
    }, []);
    return (
        <>
            {isLoading ?
                <Spinner />
                :
                <div>
                    <Navigation />
                    <Header/>
                    <Main/>
                    <Blog/>
                    <Footer />
                    <ScrollToTop />
                </div>
            }
        </>
    )
}
export default Blog1;