import card1 from "../../../assets/blog-1.jpg";
import card2 from "../../../assets/blog-2.jpg";
import card6 from "../../../assets/blog-3.jpg";
// import Slider from "react-slick";
import { FaCalendarAlt } from "react-icons/fa";
import { IoPersonCircleOutline } from "react-icons/io5";
import { IoIosArrowForward } from "react-icons/io";
import { Link,useNavigate } from "react-router-dom";
import Skeleton from "../../ourwork/components/Skeleton";
import { useData } from "../../../context/DataContext";

import { fetchTopBlogs } from "../../../utils/fetch";

import { useEffect, useState } from "react";

const Main = () => {
  // let { category } = useParams();
    const { setDataContext } = useData();
  const [data, setData] = useState([]);
  const [loader, setLoader] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoader(true);
        let res = await fetchTopBlogs();
        // console.log(res);
        setData(res);
        setLoader(false);
      } catch (error) {
        console.error(error);
        setError("Failed to fetch projects. Please try again later.");
        setLoader(false);
      }
    };

    fetchData();
  }, []);


  return (
    <section className="p-6 md:mt-12">
      <div className="container mx-auto pb-8">
        <h2 className="md:text-4xl font-bold text-gray-600 text-2xl font-raleway mb-6 text-center md:mb-12">
          Latest Blog Posts
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {loader ? (
            <>
              <Skeleton />
              <Skeleton />
              <Skeleton />
            </>
          ) : (
            data.map((post, index) => (
              <div
                key={index}
                className="bg-white p-4 rounded-lg shadow-md border border-gray-300"
              >
                <div className="image-container relative cursor-pointer">
                  <div className="image-overlay absolute inset-0 bg-black opacity-0 transition-opacity duration-300 hover:opacity-60"></div>
                  <img
                    src={post.img_url}
                    alt="Blog Image"
                    className="object-center object-cover w-[100%] aspect-[4/3]"
                  />
                  <div className="top-left-text bg-green text-white text-center text-sm font-semibold font-quicksand absolute top-4 md:pt-2 md:pb-2 md:pr-8 md:pl-8 pl-4  pr-4 pb-2 pt-2 rounded-sm">
                    {post.category}
                  </div>
                </div>

                <h3 className="text-sm md:text-lg hover:text-green cursor-pointer font-medium font-quicksand mt-4 mb-2">
                  {post.heading.length > 60
                    ? `${post.heading.slice(0, 60)}...`
                    : post.heading}
                </h3>
                <div className="text-sm text-gray-500 mb-4 mt-4 flex gap-4">
                  <div className="flex items-center">
                    <FaCalendarAlt className="mr-1 md:h-4 md:w-4 text-green cursor-pointer hover:text-purple" />
                    <p className="font-quicksand">
                      {post.created_at.slice(0, 10)}
                    </p>
                  </div>
                  <div className="flex items-center">
                    <IoPersonCircleOutline className="mr-1 md:h-6 md:w-6 text-green cursor-pointer hover:text-purple" />
                    <p className="font-quicksand md:text-sm"> {post.author}</p>
                  </div>
                </div>
                <p className="text-gray-900 mb-4 text-sm font-quicksand">
                  {post.content}
                </p>
                <div className="md:p-2 p-2 md:mb-4 mb-3 bg-green hover:bg-primary mt-8 flex items-center text-white w-32 text-center hover:bg-blue hover:text-white rounded-md cursor-pointer ">
                  <button
                    onClick={() => {
                      setDataContext(post);
                      localStorage.setItem("blog", JSON.stringify(post));
                      navigate(`/blog1`);
                    }}
                    className="text-center flex items-center"
                  >
                    Read More
                    <IoIosArrowForward className="ml-2" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </section>
  );
};

export default Main;
