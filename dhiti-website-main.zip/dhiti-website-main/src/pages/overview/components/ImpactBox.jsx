import React from 'react';

const ImpactBox = () => {
    return (


        <div class="max-w-[85rem] px-4 py-10 sm:px-6 lg:px-8 lg:py-14 mx-auto">

            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">

                <div class="group flex flex-col h-full w-full bg-white border border-gray-200 shadow-sm rounded-xl dark:bg-slate-900 dark:border-gray-700 dark:shadow-slate-700/[.7] cursor-pointer">
                    <div class="h-52 flex flex-col justify-center items-center bg-blue-600 rounded-t-xl ">

                        <img class="rounded-t-xl" src="https://annamrita.org/wp-content/uploads/2023/02/Everything-you-need-to-know-about-the-functions-of-a-food-NGO.jpg" alt="" />
                    </div>
                    <div class="p-4 md:p-6">
                        {/* <span class="block mb-1 text-xs font-semibold uppercase text-blue-600 dark:text-blue-500">
                                Atlassian API
                            </span> */}
                        <h3 class="text-xl font-semibold text-gray-800 dark:text-gray-300 dark:hover:text-white my-5">
                            Healthy Food
                        </h3>
                        <p class="mt-3 text-gray-500">
                            Providing nutritious and delicious meals for your well-being.
                        </p>
                    </div>
                    {/* <div class="mt-auto flex border-t border-gray-200 divide-x divide-gray-200 dark:border-gray-700 dark:divide-gray-700">
                                            <a class="w-full py-3 px-4 inline-flex justify-center items-center gap-x-2 text-sm font-medium rounded-es-xl bg-white text-gray-800 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none dark:bg-slate-900 dark:border-gray-700 dark:text-white dark:hover:bg-gray-800 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600" href="#">
                                                View sample
                                            </a>
                                            <a class="w-full py-3 px-4 inline-flex justify-center items-center gap-x-2 text-sm font-medium rounded-ee-xl bg-white text-gray-800 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none dark:bg-slate-900 dark:border-gray-700 dark:text-white dark:hover:bg-gray-800 dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600" href="#">
                                                View API
                                            </a>
                                    </div> */}
                </div>



                <div class="group flex flex-col h-full bg-white border border-gray-200 shadow-sm rounded-xl dark:bg-slate-900 dark:border-gray-700 dark:shadow-slate-700/[.7] cursor-pointer">
                    <div class="h-52 flex flex-col justify-center items-center ">

                        <img class="rounded-t-xl" src="https://media.istockphoto.com/id/1451088545/photo/purified-water-pouring-in-drinking-glass-on-rock-at-forest.webp?b=1&s=170667a&w=0&k=20&c=Cp9bkX4zUIdmtLzQ27rG1BWf6p3gu-JB64XUraMt0M0=&auto=format&fit=crop&w=2532&q=80" alt="" />
                    </div>
                    <div class="p-4 md:p-6">
                        <h3 class="text-xl font-semibold text-gray-800 dark:text-gray-300 dark:hover:text-white my-5">
                            Pure Water
                        </h3>
                        <p class="mt-3 text-gray-500">
                            Ensuring access to clean and safe drinking water for all.
                        </p>
                    </div>

                </div>

                <div class="group flex flex-col h-full bg-white border border-gray-200 shadow-sm rounded-xl dark:bg-slate-900 dark:border-gray-700 dark:shadow-slate-700/[.7] cursor-pointer">
                    <div class="h-52 flex flex-col justify-center items-center bg-rose-500 rounded-t-xl">

                        <img class="rounded-t-xl" src="https://media.istockphoto.com/id/1451088545/photo/purified-water-pouring-in-drinking-glass-on-rock-at-forest.webp?b=1&s=170667a&w=0&k=20&c=Cp9bkX4zUIdmtLzQ27rG1BWf6p3gu-JB64XUraMt0M0=&auto=format&fit=crop&w=2532&q=80" alt="" />
                    </div>
                    <div class="p-4 md:p-6">

                        <h3 class="text-xl font-semibold text-gray-800 dark:text-gray-300 dark:hover:text-white my-5">
                            Health Care
                        </h3>
                        <p class="mt-3 text-gray-500">
                            Delivering quality healthcare services to promote a healthy community.
                        </p>
                    </div>


                </div>

            </div>

        </div>


    );
};

export default ImpactBox;