import React from 'react';
import { Link } from 'react-router-dom';
import ImpactBox from './ImpactBox';
// import {img} from './dhiti.webp'; 

const Impact = () => {

    const data = [
        {
            heading : "Pure Water",
            des : "Providing nutritious and delicious meals for your well-being. ",
        },
        {
            heading : "Health Care",
            des : "Delivering quality healthcare services to promote a healthy community. ",
        },
        {
            heading : "Healthy Food",
            des : "Providing nutritious and delicious meals for your well-being.",
        },
        {
            heading : "Primary Education",
            des : "Empowering young minds through quality primary education programs. ",
        },
        {
            heading : "Residence Facilities",
            des : "Providing safe and comfortable housing for individuals and families.",
        },
        {
            heading : "Social Care",
            des : "Supporting and caring for our community with compassion and dedication.",
        },
    
    ]


    return (

        <div className="justify-center align-center mt-6 md:pb-10 md:mb-10 mb-8 -pb-8">
            <div className="container mx-auto">

                <div className="text-center flex flex-col justify-center items-center mx-auto mb-4 mt-16 py-10">

                    <p className="font-quicksand items-center font-bold text-2xl text-green mb-2">
                        What We Do?
                    </p>
                    <h2 className=" font-quicksand font-bold md:text-5xl text-3xl md:-p-0 p-4 text-gray-600 mb-4 md:-mb-6   md:mt-6 mt-4">
                        We believe that we can save more lives with you
                    </h2>
                </div>

                {/* <div class="flex flex-row mb-7 ">
                    <Link to="/donate">
                        <div class="flex flex-col bg-white border shadow-sm rounded-xl dark:bg-slate-900 dark:border-gray-700 dark:shadow-slate-700/[.7] px-5 mx-5 py-5 cursor-pointer">
                            <img class="w-full h-auto rounded-t-xl" src="https://annamrita.org/wp-content/uploads/2023/02/Everything-you-need-to-know-about-the-functions-of-a-food-NGO.jpg" alt="Image Description" />
                            <div class="p-4 md:p-5">
                                <h3 class="text-lg font-bold text-gray-800 dark:text-white">
                                    Healthy Food
                                </h3>
                                <p class="mt-1 text-gray-500 dark:text-gray-400">
                                    Providing nutritious and delicious meals for your well-being
                                </p>
                                <a class="mt-2 py-2 px-3 inline-flex justify-center items-center gap-x-2 text-sm font-semibold rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600" href="#">
                                    Go somewhere
                                </a>
                            </div>
                        </div>

                    </Link>



                    <Link to="/donate">

                        <div class="flex flex-col bg-white border shadow-sm rounded-xl dark:bg-slate-900 dark:border-gray-700 dark:shadow-slate-700/[.7] px-5 mx-5 py-5 cursor-pointer">
                            <img class="w-full h-auto rounded-t-xl" src="https://media.istockphoto.com/id/1451088545/photo/purified-water-pouring-in-drinking-glass-on-rock-at-forest.webp?b=1&s=170667a&w=0&k=20&c=Cp9bkX4zUIdmtLzQ27rG1BWf6p3gu-JB64XUraMt0M0=&auto=format&fit=crop&w=2532&q=80" alt="Image Description" />
                            <div class="p-4 md:p-5">
                                <h3 class="text-lg font-bold text-gray-800 dark:text-white">
                                    Pure Water
                                </h3>
                                <p class="mt-1 text-gray-500 dark:text-gray-400">
                                    Ensuring access to clean and safe drinking water for all.
                                </p>
                                <a class="mt-2 py-2 px-3 inline-flex justify-center items-center gap-x-2 text-sm font-semibold rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600" href="#">
                                    Go somewhere
                                </a>
                            </div>
                        </div>
                    </Link>

                    <Link to="/donate">
                        <div class="flex flex-col bg-white border shadow-sm rounded-xl dark:bg-slate-900 dark:border-gray-700 dark:shadow-slate-700/[.7] px-5 mx-5 py-5 cursor-pointer">
                            <img class="w-full h-auto rounded-t-xl" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR_m1JPEN7ntwTA_CEG6-mjx4qmwizQx70GLA&usqp=CAU" alt="Image Description" />
                            <div class="p-4 md:p-5">
                                <h3 class="text-lg font-bold text-gray-800 dark:text-white">
                                    Health Care
                                </h3>
                                <p class="mt-1 text-gray-500 dark:text-gray-400">
                                    Delivering quality healthcare services to promote a healthy community.
                                </p>
                                <a class="mt-2 py-2 px-3 inline-flex justify-center items-center gap-x-2 text-sm font-semibold rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600" href="#">
                                    Go somewhere
                                </a>
                            </div>
                        </div>
                    </Link>
                </div>
                <div class="flex flex-row ">

                    <Link to="/donate">

                        <div class="flex flex-col bg-white border shadow-sm rounded-xl dark:bg-slate-900 dark:border-gray-700 dark:shadow-slate-700/[.7] px-5 mx-5 py-5 cursor-pointer">
                            <img class="w-full h-auto rounded-t-xl" src="https://www.sruti.org.in/wp-content/uploads/2021/05/education-image.jpg" alt="Image Description" />
                            <div class="p-4 md:p-5">
                                <h3 class="text-lg font-bold text-gray-800 dark:text-white">
                                    Primary Education
                                </h3>
                                <p class="mt-1 text-gray-500 dark:text-gray-400">
                                    Empowering young minds through quality primary education programs.
                                </p>
                                <a class="mt-2 py-2 px-3 inline-flex justify-center items-center gap-x-2 text-sm font-semibold rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600" href="#">
                                    Go somewhere
                                </a>
                            </div>
                        </div>
                    </Link>

                    <Link to="/donate">
                        <div class="flex flex-col bg-white border shadow-sm rounded-xl dark:bg-slate-900 dark:border-gray-700 dark:shadow-slate-700/[.7] px-5 mx-5 py-5 cursor-pointer">
                            <img class="w-full h-auto rounded-t-xl" src="https://www.sruti.org.in/wp-content/uploads/2021/05/education-image.jpg" alt="Image Description" />
                            <div class="p-4 md:p-5">
                                <h3 class="text-lg font-bold text-gray-800 dark:text-white">
                                    Residence Facilities
                                </h3>
                                <p class="mt-1 text-gray-500 dark:text-gray-400">
                                    Providing safe and comfortable housing for individuals and families.
                                </p>
                                <a class="mt-2 py-2 px-3 inline-flex justify-center items-center gap-x-2 text-sm font-semibold rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600" href="#">
                                    Go somewhere
                                </a>
                            </div>
                        </div>
                    </Link>
                    <Link to="/donate">
                        <div class="flex flex-col bg-white border shadow-sm rounded-xl dark:bg-slate-900 dark:border-gray-700 dark:shadow-slate-700/[.7] px-5 mx-5 py-5 cursor-pointer">
                            <img class="w-full h-auto rounded-t-xl" src="https://www.sruti.org.in/wp-content/uploads/2021/05/education-image.jpg" alt="Image Description" />
                            <div class="p-4 md:p-5">
                                <h3 class="text-lg font-bold text-gray-800 dark:text-white">
                                    Social Care
                                </h3>
                                <p class="mt-1 text-gray-500 dark:text-gray-400">
                                    Supporting and caring for our community with compassion and dedication.
                                </p>
                                <a class="mt-2 py-2 px-3 inline-flex justify-center items-center gap-x-2 text-sm font-semibold rounded-lg border border-transparent bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none dark:focus:outline-none dark:focus:ring-1 dark:focus:ring-gray-600" href="#">
                                    Go somewhere
                                </a>
                            </div>
                        </div>
                        </Link>
                </div> */}


                <div class="max-w-[85rem] px-4 py-10 sm:px-6 lg:px-8 lg:py-14 mx-auto">

                    <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">

                       {data.map((result, idx) => (
                       
                        <div class="group flex flex-col h-full w-full bg-white border border-gray-200 shadow-sm rounded-xl dark:bg-slate-900 dark:border-gray-700 dark:shadow-slate-700/[.7] cursor-pointer  ">
                            <div class="h-52 flex flex-col justify-center items-center bg-blue-600 rounded-t-xl my-5">

                                <img class="rounded-t-xl" src="https://annamrita.org/wp-content/uploads/2023/02/Everything-you-need-to-know-about-the-functions-of-a-food-NGO.jpg" alt="" />
                            </div>
                            <div class="p-4 md:p-6  ">
                               
                                <h3 class="text-xl font-semibold text-gray-800 dark:text-gray-300 dark:hover:text-white my-5 ">
                                    
                                    {result.heading}
                                </h3>
                                <p class="mt-3 text-gray-500">
                                    
                                    {result.des}
                                </p>
                            </div>
                           
                        </div>
                   ))}



                      

                    </div>

                </div>

                




            </div>
        </div>
    );
};

export default Impact;