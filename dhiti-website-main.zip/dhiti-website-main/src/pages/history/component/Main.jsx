import React from 'react';

const Main = () => {

    const historydata = [
        {
            yearheading: "1971- 1979 ",
            yearsub: "THE ORIGINS",

            datas: [
                {
                    year: "2022",
                    descrip: "In 1971, a group of students from the University of Madras, under the Young Students Movement for Development (YSMD), travelled to West Bengal to provide relief to people affected by the war on Bangladesh border. In October 1971, a few of them moved to Kendrapara district, in eastern Odisha, in the aftermath of a devastating cyclone to start relief operations. They were joined by students from the local area. After the initial relief efforts, they worked on restoring livelihoods through improvements in irrigated agriculture.",
                    img: "https://www.gramvikas.org/wp-content/themes/gramvikas/img/history/History_1979.jpg",

                },
                {
                    year: "2022",
                    descrip: "In 1976, the group moved to Ganjam district, Odisha, at the behest of the District Administration to initiate a dairy development project. As tribal communities resisted the idea of dairying, the group made efforts to address immediate issues of concern – ill-health, illiteracy, land alienation and degradation of natural resources.",
                    img: "",


                }, {
                    year: "2022",
                    descrip: "The work done by the volunteers of YSMD in Ganjam led to the founding of Gram Vikas, which was registered on 22 January 1979.",
                    img: "",
                }
            ]

        },
        {
            yearheading: "1980- 1989",
            yearsub: "THE FIRST DECADE",

            datas: [
                {
                    year: "1980",
                    descrip: "The work of the YSMD volunteers was in the villages of Kerandimal hills, in Digapahandi, Chikiti and Kukudakhandi blocks of Ganjam. The ‘Kerandimal Gana Sangathan’, a tribal people’s organisation, was mobilised to oust liquor merchants and exploitative moneylenders. During the same period, successful experiments were made in setting up biogas plants to provide alternative fuel for households. Non-formal education and adult literacy centres were set up, across tribal villages, by Gram Vikas to address the literacy gap.",
                    img: "https://www.gramvikas.org/wp-content/themes/gramvikas/img/history/History_1st_Decade_1980_Adult_education.jpg",

                },
                {
                    year: "1982",
                    descrip: "The Kerandimal Middle Education School started in 1982, as a residential school, to cater to children from remote habitations of Ganjam.",
                    img: "https://www.gramvikas.org/wp-content/themes/gramvikas/img/history/History_1st_Decade_1982.jpg",


                }, {
                    year: "1983",
                    descrip: "As part of the National Biogas Extension Programme, Gram Vikas undertook research and development in biogas plant design, trained a large pool of masons and technicians and built 54,000 biogas plants in villages across Odisha during the next 10 years.",
                    img: "https://www.gramvikas.org/wp-content/themes/gramvikas/img/history/History_1st_Decade_1983_Biogas.jpg",
                },
                {
                    year: "1985",
                    descrip: "The Social Forestry programme was launched, mobilising tribal communities to undertake largescale tree plantations on individual and community land. This was done in collaboration with the National Wastelands Development Board. Over 25,000 acres of private and community wasteland were restored through work on soil and water conservation and fuel, fodder and fruit plantations.",
                    img: "https://www.gramvikas.org/wp-content/themes/gramvikas/img/history/History_1st_Decade_1985_Social_forestry.jpg",
                },{
                    year : "1986",
                    descrip : "The recurring droughts in the tribal-dominated Thuamul Rampur block of Kalahandi District led Gram Vikas to start working with the communities there. The Integrated Tribal Development Programme (ITDP) was established.",
                    img: "https://www.gramvikas.org/wp-content/themes/gramvikas/img/history/History_1st_Decade_1986.jpg",
                },
            ]

        },
        {
            yearheading: "1990- 1999",
            yearsub: "THE SECOND DECADE",

            datas: [
                {
                    year: "1990",
                    descrip: "Building upon the community linkages established through the Social Forestry programme, the Integrated Tribal Development Programme (ITDP) was initiated in the Tumba region of Patrapur block in Ganjam.",
                    img: "",

                },
                {
                    year: "1992",
                    descrip: "The Mahendratanaya Ashram School, a residential school catering to children from the Mahendragiri area of Gajapati district was set up.",
                    img: "https://www.gramvikas.org/wp-content/themes/gramvikas/img/history/History_2nd_Decade_1992_Ashram_School.jpg",


                }, {
                    year: "1993",
                    descrip: "After a decade of intensive promotion of biogas technology, across villages in Odisha, Gram Vikas decided to withdraw from the programme. A large number of technicians and masons were supported to branch out on their own, as renewable energy entrepreneurs or to work with other agencies promoting biogas technology.",
                    img: "https://www.gramvikas.org/wp-content/themes/gramvikas/img/history/History_2nd_Decade_1993_RHEP.jpg",
                }, {
                    year: "1994",
                    descrip: "The ITDP was initiated in the Karadasing area to build upon the linkages established through the Biogas and Social Forestry programmes in the Rayagada block of Gajapati district.",
                    img:" https://www.gramvikas.org/wp-content/themes/gramvikas/img/history/History_2nd_Decade_1994_Biogas.jpg",
                }
            ]

        }

    ]

    return (
        <>
            <section class="dark:bg-gray-800 dark:text-gray-100">
                <div class="container max-w-6xl px-4 py-12 mx-auto">

                    {historydata.map((data) => (


                        <div class="grid gap-4 mx-4 sm:grid-cols-12 mb-10">
                            <div class="col-span-12 sm:col-span-3">
                                <div class="text-center sm:text-left mb-14 before:block before:w-24 before:h-3 before:mb-5 before:rounded-md before:mx-auto sm:before:mx-0 before:bg-green">
                                    <h3 class="text-3xl font-semibold">{data.yearheading}</h3>
                                    <span class="text-sm font-bold tracking-wider uppercase dark:text-gray-400">{data.yearsub}</span>
                                </div>
                            </div>
                            <div class="relative col-span-12 px-4 space-y-6 sm:col-span-9">
                                <div class="col-span-12 space-y-12 relative px-4 sm:col-span-8 sm:space-y-8 sm:before:absolute sm:before:top-2 sm:before:bottom-0 sm:before:w-0.5 sm:before:-left-3 before:bg-black">
                                    {data.datas.map((das) => (
                                        <div class="flex flex-col sm:relative sm:before:absolute sm:before:top-2 sm:before:w-4 sm:before:h-4 sm:before:rounded-full sm:before:left-[-35px] sm:before:z-[1] before:bg-green">
                                            <h3 class="text-xl font-semibold tracking-wide">{das.year}</h3>
                                            <time class="text-xs tracking-wide uppercase dark:text-gray-400">Dec 2020</time>
                                            <p class="mt-3">{das.descrip}</p>
                                            <img className='mt-5 mb-5' src={das.img} alt="" />
                                        </div>
                                    ))}

                                    {/* <div class="flex flex-col sm:relative sm:before:absolute sm:before:top-2 sm:before:w-4 sm:before:h-4 sm:before:rounded-full sm:before:left-[-35px] sm:before:z-[1] before:dark:bg-violet-400">
                                <h3 class="text-xl font-semibold tracking-wide">Aliquam sit amet nunc ut</h3>
                                <time class="text-xs tracking-wide uppercase dark:text-gray-400">Jul 2019</time>
                                <p class="mt-3">Morbi vulputate aliquam libero non dictum. Aliquam sit amet nunc ut diam aliquet tincidunt nec nec dui. Donec mollis turpis eget egestas sodales.</p>
                                        </div>
                                        <div class="flex flex-col sm:relative sm:before:absolute sm:before:top-2 sm:before:w-4 sm:before:h-4 sm:before:rounded-full sm:before:left-[-35px] sm:before:z-[1] before:dark:bg-violet-400">
                                            <h3 class="text-xl font-semibold tracking-wide">Pellentesque habitant morbi</h3>
                                            <time class="text-xs tracking-wide uppercase dark:text-gray-400">Jan 2016</time>
                                            <p class="mt-3">Suspendisse tincidunt, arcu nec faucibus efficitur, justo velit consectetur nisl, sit amet condimentum lacus orci nec purus. Mauris quis quam suscipit, vehicula felis id, vehicula enim.</p>
                                    </div> */}
                                </div>
                            </div>
                        </div>

                    ))}
                </div>


            </section>

        </>
    );
};

export default Main;