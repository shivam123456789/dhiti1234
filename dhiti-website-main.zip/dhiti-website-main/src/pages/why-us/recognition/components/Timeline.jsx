import React from "react";
import { IoIosArrowForward } from "react-icons/io";
import { Link } from "react-router-dom";

const Timeline = () => {
  return (
    <div className="font-quicksand flex flex-col items-center justify-center mt-8 px-5 pb-16">
      {" "}
      <ol className="relative border-s border-primary dark:border-primary md:max-w-[1000px]">
        <li className="mb-10 ms-4">
          <div className="absolute w-3 h-3 bg-green rounded-full mt-1.5 -start-1.5 border border-primary dark:border-gray-900 dark:bg-gray-700"></div>
          <time className="mb-1 text-base font-semibold leading-none text-green dark:text-green">
            February 2022
          </time>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            10th Earth Care Awards 2022 for Community-based Climate Action
          </h3>
          <p className="mb-4 text-lg font-normal text-primary dark:text-primary">
            Gram Vikas won the 10th Earth Care Awards 2022 by JSW and The Times
            of India group under the category of Community-based Climate Action
            for increasing the resilience capacity of the communities to tackle
            challenges arising out of climate change. The award recognised our
            work in Social and Agroforestry project restoring 540 acres of
            degraded land in Kalahandi.
          </p>
          <img
            src="https://www.gramvikas.org/wp-content/uploads/2019/04/2015_MoRD_Good_Practices_in_Rural_Development.jpg"
            className="mt-4 w-full max-w-[100%] sm:max-w-[70%] mb-4"
            alt="Responsive Image"
          />
          <Link
            href="#"
            className="inline-flex items-center px-4 py-2 text-lg font-medium text-gray-900 bg-white border-2 border-primary rounded-lg hover:bg-green hover:text-white focus:z-10 focus:ring-4 focus:outline-none focus:ring-gray-100 focus:text-blue-700 dark:bg-gray-800 dark:text-green dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700 dark:focus:ring-gray-700"
          >
            Learn more
            <IoIosArrowForward className="w-3 h-3 ms-2 rtl:rotate-180" />
          </Link>
        </li>
        <li className="mb-10 ms-4">
          <div className="absolute w-3 h-3 bg-green rounded-full mt-1.5 -start-1.5 border border-primary dark:border-gray-900 dark:bg-gray-700"></div>
          <time className="mb-1 text-base font-semibold leading-none text-green dark:text-green">
            March 2022
          </time>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Sat Paul Mittal National Award 2021 for outstanding service to
            humanity
          </h3>
          <p className="text-lg font-normal text-gray-500 dark:text-green">
            All of the pages and components are first designed in Figma and we
            keep a parity between the two versions even as we update the
            project.
          </p>
        </li>
        <li className="ms-4">
          <div className="absolute w-3 h-3 bg-green rounded-full mt-1.5 -start-1.5 border border-primary dark:border-gray-900 dark:bg-gray-700"></div>
          <time className="mb-1 text-base font-semibold leading-none text-green dark:text-green">
            April 2022
          </time>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Lorem ipsum dolor sit
          </h3>
          <p className="text-lg font-normal text-gray-500 dark:text-green">
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nisi
            consequuntur voluptas commodi fugit odit sapiente, neque itaque
            voluptates beatae. Optio iusto magnam ab eum earum officia rem et,
            culpa obcaecati!
          </p>
          <img
            src="https://www.gramvikas.org/wp-content/uploads/2019/04/2016_Parichay_Foundation.jpg"
            className="mt-4 w-full max-w-[100%] sm:max-w-[70%]"
            alt="Responsive Image"
          />
        </li>
      </ol>
    </div>
  );
};

export default Timeline;
