import React from "react";

const Card = () => {
  let catData = [
    {
      heading: "Water",
      category:"water",
      location:"/ourwork/water",
      description: "Your donation is a bridge to a brighter, hopeful future",
    },
    {
      heading: "Livelihood",
      category:"livelihood",
      location:"/ourwork/livelihood",
      description: "Your donation is a bridge to a brighter, hopeful future",
    },
    {
      heading: "Sanitation & Health",
      category:"health",
      location:"/ourwork/water",
      description: "Your donation is a bridge to a brighter, hopeful future",
    },
  ];
  return (
    <>
      <div className="max-w-[1300px] mx-auto flex flex-col items-center justify-center">
        <section className=" font-quicksand p-4 lg:p-8 dark:bg-gray-800 dark:text-gray-100">
          <div className="justify-center align-center mt-8 pb-16">
            <div className="">
              <div className="text-center mx-auto mb-4 mt-24">
                <p className="font-quicksand items-center font-bold text-4xl text-green mb-2 ">
                  Water
                </p>
                <hr className="border-2 " />
                <h2 className=" font-quicksand font-bold md:text-2xl text-2xl text-gray-600 mb-4 md:max-w-[700px] md:ml-[25%] mt-6 md:p-0 p-2">
                  Your donation is a bridge to a brighter, hopeful future
                </h2>
              </div>
            </div>
          </div>

          <div className="container mx-auto space-y-12">
            <div className="flex flex-col overflow-hidden rounded-md shadow-sm lg:flex-row">
              <img
                src="https://source.unsplash.com/640x480/?1"
                alt=""
                className="h-80 dark:bg-gray-500 aspect-video"
              />
              <div className="flex flex-col justify-center flex-1 p-6 dark:bg-gray-900">
                <span className="text-xs uppercase dark:text-gray-400">
                  Join, it&apos;s free
                </span>
                <h3 className="text-3xl font-bold">
                  We're not reinventing the wheel
                </h3>
                <p className="my-6 dark:text-gray-400">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor
                  aliquam possimus quas, error esse quos.
                </p>
                <button type="button" className="self-start">
                  Action
                </button>
              </div>
            </div>
            <div className="flex flex-col overflow-hidden rounded-md shadow-sm lg:flex-row-reverse">
              <img
                src="https://source.unsplash.com/640x480/?2"
                alt=""
                className="h-80 dark:bg-gray-500 aspect-video"
              />
              <div className="flex flex-col justify-center flex-1 p-6 dark:bg-gray-900">
                <span className="text-xs uppercase dark:text-gray-400">
                  Join, it's free
                </span>
                <h3 className="text-3xl font-bold">
                  We're not reinventing the wheel
                </h3>
                <p className="my-6 dark:text-gray-400">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor
                  aliquam possimus quas, error esse quos.
                </p>
                <button type="button" className="self-start">
                  Action
                </button>
              </div>
            </div>
            <div className="flex justify-center">
              <button
                type="submit"
                className="p-4 border-2 border-green text-black text-xl hover:bg-green font-semibold hover:text-white mt-4 w-auto font-quicksand rounded-md text-center align-center justify-center items-center whitespace-nowrap"
              >
                {"LEARN MORE ABOUT OUR WORK IN WATER"}
              </button>
            </div>
          </div>
        </section>

        {/* <section className=" font-quicksand p-4 lg:p-8 dark:bg-gray-800 dark:text-gray-100">
          <div className="justify-center align-center pb-16">
            <div className="">
              <div className="text-center mx-auto mb-4 mt-24">
                <p className="font-quicksand items-center font-bold text-4xl text-green mb-2 ">
                  Livelihoods
                </p>
                <hr className="border-2 " />
                <h2 className=" font-quicksand font-bold md:text-2xl text-2xl text-gray-600 mb-4 md:max-w-[700px] md:ml-[25%] mt-6 md:p-0 p-2">
                  Your donation is a bridge to a brighter, hopeful future
                </h2>
              </div>
            </div>
          </div>

          <div className="container mx-auto space-y-12">
            <div className="flex flex-col overflow-hidden rounded-md shadow-sm lg:flex-row">
              <img
                src="https://source.unsplash.com/640x480/?1"
                alt=""
                className="h-80 dark:bg-gray-500 aspect-video"
              />
              <div className="flex flex-col justify-center flex-1 p-6 dark:bg-gray-900">
                <span className="text-xs uppercase dark:text-gray-400">
                  Join, it&apos;s free
                </span>
                <h3 className="text-3xl font-bold">
                  We're not reinventing the wheel
                </h3>
                <p className="my-6 dark:text-gray-400">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor
                  aliquam possimus quas, error esse quos.
                </p>
                <button type="button" className="self-start">
                  Action
                </button>
              </div>
            </div>
            <div className="flex flex-col overflow-hidden rounded-md shadow-sm lg:flex-row-reverse">
              <img
                src="https://source.unsplash.com/640x480/?2"
                alt=""
                className="h-80 dark:bg-gray-500 aspect-video"
              />
              <div className="flex flex-col justify-center flex-1 p-6 dark:bg-gray-900">
                <span className="text-xs uppercase dark:text-gray-400">
                  Join, it's free
                </span>
                <h3 className="text-3xl font-bold">
                  We're not reinventing the wheel
                </h3>
                <p className="my-6 dark:text-gray-400">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor
                  aliquam possimus quas, error esse quos.
                </p>
                <button type="button" className="self-start">
                  Action
                </button>
              </div>
            </div>
            <div className="flex justify-center">
              <button
                type="submit"
                className="p-4 border-2 border-green text-black text-xl hover:bg-green font-semibold hover:text-white mt-4 w-auto font-quicksand rounded-md text-center align-center justify-center items-center whitespace-nowrap"
              >
                {"LEARN MORE ABOUT OUR WORK IN LIVELIHOODS"}
              </button>
            </div>
          </div>
        </section>

        <section className=" font-quicksand p-4 lg:p-8 dark:bg-gray-800 dark:text-gray-100">
          <div className="justify-center align-center  pb-16">
            <div className="">
              <div className="text-center mx-auto mb-4 mt-24">
                <p className="font-quicksand items-center font-bold text-4xl text-green mb-2 ">
                  Sanitation & Health
                </p>
                <hr className="border-2 " />
                <h2 className=" font-quicksand font-bold md:text-2xl text-2xl text-gray-600 mb-4 md:max-w-[700px] md:ml-[25%] mt-6 md:p-0 p-2">
                  Your donation is a bridge to a brighter, hopeful future
                </h2>
              </div>
            </div>
          </div>

          <div className="container mx-auto space-y-12">
            <div className="flex flex-col overflow-hidden rounded-md shadow-sm lg:flex-row">
              <img
                src="https://source.unsplash.com/640x480/?1"
                alt=""
                className="h-80 dark:bg-gray-500 aspect-video"
              />
              <div className="flex flex-col justify-center flex-1 p-6 dark:bg-gray-900">
                <span className="text-xs uppercase dark:text-gray-400">
                  Join, it&apos;s free
                </span>
                <h3 className="text-3xl font-bold">
                  We're not reinventing the wheel
                </h3>
                <p className="my-6 dark:text-gray-400">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor
                  aliquam possimus quas, error esse quos.
                </p>
                <button type="button" className="self-start">
                  Action
                </button>
              </div>
            </div>
            <div className="flex flex-col overflow-hidden rounded-md shadow-sm lg:flex-row-reverse">
              <img
                src="https://source.unsplash.com/640x480/?2"
                alt=""
                className="h-80 dark:bg-gray-500 aspect-video"
              />
              <div className="flex flex-col justify-center flex-1 p-6 dark:bg-gray-900">
                <span className="text-xs uppercase dark:text-gray-400">
                  Join, it's free
                </span>
                <h3 className="text-3xl font-bold">
                  We're not reinventing the wheel
                </h3>
                <p className="my-6 dark:text-gray-400">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor
                  aliquam possimus quas, error esse quos.
                </p>
                <button type="button" className="self-start">
                  Action
                </button>
              </div>
            </div>
            <div className="flex justify-center">
              <button
                type="submit"
                className="p-4 border-2 border-green text-black text-xl hover:bg-green font-semibold hover:text-white mt-4 w-auto font-quicksand rounded-md text-center align-center justify-center items-center whitespace-nowrap"
              >
                {"LEARN MORE ABOUT OUR WORK IN SAITATION & HEALTH"}
              </button>
            </div>
          </div>
        </section>
        <section className=" font-quicksand p-4 lg:p-8 dark:bg-gray-800 dark:text-gray-100">
          <div className="justify-center align-center pb-16">
            <div className="">
              <div className="text-center mx-auto mb-4 mt-24">
                <p className="font-quicksand items-center font-bold text-4xl text-green mb-2 ">
                  Education & Youth
                </p>
                <hr className="border-2 " />
                <h2 className=" font-quicksand font-bold md:text-2xl text-2xl text-gray-600 mb-4 md:max-w-[700px] md:ml-[25%] mt-6 md:p-0 p-2">
                  Your donation is a bridge to a brighter, hopeful future
                </h2>
              </div>
            </div>
          </div>

          <div className="container mx-auto space-y-12">
            <div className="flex flex-col overflow-hidden rounded-md shadow-sm lg:flex-row">
              <img
                src="https://source.unsplash.com/640x480/?1"
                alt=""
                className="h-80 dark:bg-gray-500 aspect-video"
              />
              <div className="flex flex-col justify-center flex-1 p-6 dark:bg-gray-900">
                <span className="text-xs uppercase dark:text-gray-400">
                  Join, it&apos;s free
                </span>
                <h3 className="text-3xl font-bold">
                  We're not reinventing the wheel
                </h3>
                <p className="my-6 dark:text-gray-400">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor
                  aliquam possimus quas, error esse quos.
                </p>
                <button type="button" className="self-start">
                  Action
                </button>
              </div>
            </div>
            <div className="flex flex-col overflow-hidden rounded-md shadow-sm lg:flex-row-reverse">
              <img
                src="https://source.unsplash.com/640x480/?2"
                alt=""
                className="h-80 dark:bg-gray-500 aspect-video"
              />
              <div className="flex flex-col justify-center flex-1 p-6 dark:bg-gray-900">
                <span className="text-xs uppercase dark:text-gray-400">
                  Join, it's free
                </span>
                <h3 className="text-3xl font-bold">
                  We're not reinventing the wheel
                </h3>
                <p className="my-6 dark:text-gray-400">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor
                  aliquam possimus quas, error esse quos.
                </p>
                <button type="button" className="self-start">
                  Action
                </button>
              </div>
            </div>
            <div className="flex justify-center">
              <button
                type="submit"
                className="p-4 border-2 border-green text-black text-xl hover:bg-green font-semibold hover:text-white mt-4 w-auto font-quicksand rounded-md text-center align-center justify-center items-center whitespace-nowrap"
              >
                {"LEARN MORE ABOUT OUR WORK IN EDUCATION & YOUTH"}
              </button>
            </div>
          </div>
        </section> */}
      </div>
    </>
  );
};

export default Card;
