import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import Card from "./components/Card";
import Navigation from "../../components/Navigation";
import Header from "./components/Header";
import Footer from "../../components/Footer";
import ScrollToTop from "../../components/Scroll";
import Spinner from "../../components/Spinner"; 
import { fetchTopProject } from "../../../utils/fetch";

const Impact = () => {
    const location = useLocation();
    const [data, setData] = useState([]);
    const [loader, setLoader] = useState(false);
    const [error, setError] = useState("");
  
    useEffect(() => {
      const fetchData = async () => {
        try {
          setLoader(true);
          let res = await fetchTopProject();
          setData(res.data);
          setLoader(false);
        } catch (error) {
          console.error(error);
          setError("Failed to fetch projects. Please try again later.");
          setLoader(false);
        }
      };
  
      fetchData();
},[]);
  
    // useEffect(() => {
    //   console.log(data); // This will log every time `data` changes.
    // }, [data]);
  



    useEffect(() => {
      window.scrollTo(0, 0);
    }, [location]);
  
    const [isLoading, setIsLoading] = useState(false);
    
    useEffect(() => {
      const timer = setTimeout(() => {
        setIsLoading(false);
      }, 1000);
  
      return () => {
        clearTimeout(timer); // Clear the timeout when the component is unmounted or the dependency changes
      };
    }, []);
  
    return (
      <>
        {isLoading ? (
          <Spinner />
        ) : (
          <div>
            <Navigation />
            <section style={{ marginTop: "-40px" }}>
              <Header />
              <Card/>
  
              <Footer />
              <ScrollToTop />
            </section>
          </div>
        )}
      </>
    );
};

export default Impact;