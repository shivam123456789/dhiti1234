import { HiBadgeCheck } from "react-icons/hi";
// import { useEffect, useRef } from 'react';
import { useInView } from "react-intersection-observer";

const Home = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <div className="justify-center align-center mt-8 pb-16">
      <div className="">
        <div className="text-center mx-auto mb-4 mt-24">
          <p className="font-quicksand items-center font-bold text-3xl text-green mb-2 ">
            OUR APPROACH: MANTRA
          </p>
          <h2 className=" font-quicksand font-bold md:text-xl text-xl text-gray-600 mb-4 md:max-w-[900px] md:ml-[25%] mt-6 md:p-0 p-2">
            The Movement and Action Network for Transformation of Rural Areas
            (MANTRA) approach promotes a socially inclusive, gender equitable,
            self-managed and financially viable model of sustainable and
            holistic development, where everybody benefits. The principles that
            guide our approach demonstrate our commitment to such a development
            process.
          </h2>
        </div>
      </div>
    </div>
  );
};

export default Home;
