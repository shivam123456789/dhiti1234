import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { Button } from "@material-tailwind/react";

import Navigation from "../components/Navigation";
import Header from "./components/Header";
import WhyUs from "./components/WhyUs";
import Footer from "../components/Footer";
import ScrollToTop from "../components/Scroll";
import Approach from "./components/Approach";
import Blog from "../blog/components/Main";
import Spinner from "../components/Spinner";

const Home = () => {
  const location = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);

  const [isLoading, setIsLoading] = useState(true);
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);

    return () => {
      clearTimeout(timer); // Clear the timeout when the component is unmounted or the dependency changes
    };
  }, []);

  return (
    <>
      {isLoading ? (
        <Spinner />
      ) : (
        <div>
          <Navigation />
          <section style={{ marginTop: "-40px" }}>
            <Header />
            <Approach />
            <WhyUs />
            <Blog />
            <Footer />
            <ScrollToTop />
          </section>
        </div>
      )}
    </>
  );
};

export default Home;
