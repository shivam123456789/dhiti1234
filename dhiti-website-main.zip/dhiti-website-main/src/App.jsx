import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { DataProvider } from "./context/DataContext";
import Home from "./pages/home/Home";
import About from "./pages/overview/About";
import Founder from "./pages/founder/Founder";
import Blog from "./pages/blog/Blog";
import History from "./pages/history/History";
import Upcoming from "./pages/upcoming/Upcoming";
import Recent from "./pages/events/Events";
import Gallery from "./pages/gallery/Gallery";
import Contact from "./pages/contact/Contact";
import Donate from "./pages/donate/Donate";
import Blog1 from "./pages/blog/blogs/blog1/Blog1";
// import Blog2 from './pages/blog/blogs/blog2/Blog2';
// import Blog3 from './pages/blog/blogs/blog3/Blog3';
import Recent1 from "./pages/event-blogs/first/Main";
import VisionAndApproach from "./pages/why-us/VisionAndApproach";

import Patner from "./pages/patner/Patner";
import Project from "./pages/Project/Project";
import Recognition from "./pages/why-us/recognition/Recognition";
import Impact from "./pages/why-us/impact/Impact";
import Brand from "./pages/brandandteam/Brand";
import Ethos from "./pages/ourethos/Ethos";
import Library from "./pages/library/Library";
import Discloser from "./pages/mandatory-disclosure/Discloser";
import OurWork from "./pages/ourwork/dynamic/OurWork";
import { exact } from "prop-types";
import ProjectWork from "./pages/ourwork/dynamic/Project";

const App = () => {
  return (
    <DataProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="*" element={<Home />} />
          {/* <Route
            path="/whyus/vision-and-approach"
            element={<VisionAndApproach />}
          />
          <Route path="/whyus/recognition" element={<Recognition />} />
          <Route path="/whyus/impact" element={<Impact />} />
          <Route path="/brandandteam" element={<Brand />} />
       

          <Route path="/overview" element={<About />} />
          <Route path="/history" element={<History />} />
          <Route path="/founder" element={<Founder />} />
          <Route path="/upcoming" element={<Upcoming />} />
          <Route path="/recent" element={<Recent />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/donate" element={<Donate />} />
        
          <Route path="/inauguration" element={<Recent1 />} />
          <Route path="/gallery" element={<Gallery />} />
          <Route path="/partner" element={<Patner />} />
          <Route path="/ethos&culture" element={<Ethos />} />
          <Route path="/library" element={<Library />} />
          <Route path="/mandatory-disclosure" element={<Discloser />} />



          <Route path="/blog" element={<Blog />} />
          <Route path="/blog1" element={<Blog1 />} />
          
           */}

          <Route path="ourwork">
            <Route path="project" element={<ProjectWork />} />
            <Route path=":category" element={<OurWork />} />
          </Route>
        </Routes>
      </Router>
    </DataProvider>
  );
};

{
  /* <Route path="/overview" element={<Causes />} /> */
}
export default App;
